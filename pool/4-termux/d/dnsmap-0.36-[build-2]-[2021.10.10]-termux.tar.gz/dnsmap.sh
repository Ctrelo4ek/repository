#!/system/bin/sh

# SHELL SCRIPT (SH)

name="dnsmap"
version="0.36 [Build 2]"

# 0.36 [Build 2]

source="Termux"

chown 0.2000 "/system/xbin/dnsmap"
chmod 0755 "/system/xbin/dnsmap"

chown 0.2000 "/system/xbin/dnsmap-bulk"
chmod 0755 "/system/xbin/dnsmap-bulk"

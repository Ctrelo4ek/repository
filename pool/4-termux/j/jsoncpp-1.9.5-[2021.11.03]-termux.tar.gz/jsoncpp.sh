#!/system/bin/sh

# SHELL SCRIPT (SH)

name="jsoncpp"
version="1.9.5"

# 1.9.5

source="Termux"

chown 0.0 "/system/lib/libjsoncpp.so"
chmod 0644 "/system/lib/libjsoncpp.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libjsoncpp.so"

# 11.0

source_2="Android"

chown 0.0 "/system/lib64/libjsoncpp.so"
chmod 0644 "/system/lib64/libjsoncpp.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libjsoncpp.so"

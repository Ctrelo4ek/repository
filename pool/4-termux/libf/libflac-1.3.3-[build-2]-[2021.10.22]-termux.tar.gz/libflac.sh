#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libflac"
version="1.3.3 [Build 2] [2021.10.22]"

# 1.3.3 [Build 2] [2021.10.22]

source="Termux"

chown 0.0 "/system/lib/libFLAC.so"
chmod 0644 "/system/lib/libFLAC.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libFLAC.so"

chown 0.0 "/system/lib/libFLAC++.so"
chmod 0644 "/system/lib/libFLAC++.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libFLAC++.so"

chown 0.0 "/system/lib64/libFLAC.so"
chmod 0644 "/system/lib64/libFLAC.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libFLAC.so"

chown 0.0 "/system/lib64/libFLAC++.so"
chmod 0644 "/system/lib64/libFLAC++.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libFLAC++.so"

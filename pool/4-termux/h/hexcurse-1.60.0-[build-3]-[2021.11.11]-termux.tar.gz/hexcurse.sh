#!/system/bin/sh

# SHELL SCRIPT (SH)

name="hexcurse"
version="1.60.0 [Build 3]"

# 1.60.0 [Build 3]

source="Termux"

chown 0.2000 "/system/xbin/hexcurse"
chmod 0755 "/system/xbin/hexcurse"

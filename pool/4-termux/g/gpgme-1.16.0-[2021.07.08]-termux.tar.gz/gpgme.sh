#!/system/bin/sh

# SHELL SCRIPT (SH)

name="gpgme"
version="1.15.0 [API 1]"

# 1.15.0 [API 1]

source="Termux"
source_2="https://www.gnupg.org/related_software/gpgme"

chown 0.0 "/system/lib/libgpgme.so"
chmod 0644 "/system/lib/libgpgme.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgpgme.so"

chown 0.0 "/system/lib64/libgpgme.so"
chmod 0644 "/system/lib64/libgpgme.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgpgme.so"

chown 0.2000 "/system/xbin/gpgme-config"
chmod 0755 "/system/xbin/gpgme-config"

chown 0.2000 "/system/xbin/gpgme-json"
chmod 0755 "/system/xbin/gpgme-json"

chown 0.2000 "/system/xbin/gpgme-tool"
chmod 0755 "/system/xbin/gpgme-tool"

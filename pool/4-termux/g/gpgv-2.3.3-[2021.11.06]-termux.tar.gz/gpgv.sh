#!/system/bin/sh

# SHELL SCRIPT (SH)

name="gpgv"
version="2.2.3"

# 2.2.3

source="Termux"

chown 0.2000 "/system/xbin/gpgv"
chmod 0755 "/system/xbin/gpgv"

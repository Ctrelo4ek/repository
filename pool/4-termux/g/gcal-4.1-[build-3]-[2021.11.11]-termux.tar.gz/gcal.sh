#!/system/bin/sh

# SHELL SCRIPT (SH)

name="gcal"
version="4.1 [Build 3]"

# 4.1 [Build 3]

source="Termux"

chown -hR 0.0 "/system/etc/gcal"
chmod -R 0644 "/system/etc/gcal"

find "/system/etc/gcal" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/gcal" "/system/usr/share/gcal"

chown 0.2000 "/system/xbin/gcal"
chmod 0755 "/system/xbin/gcal"

chown 0.2000 "/system/xbin/gcal2txt"
chmod 0755 "/system/xbin/gcal2txt"

chown 0.2000 "/system/xbin/tcal"
chmod 0755 "/system/xbin/tcal"

chown 0.2000 "/system/xbin/txt2gcal"
chmod 0755 "/system/xbin/txt2gcal"

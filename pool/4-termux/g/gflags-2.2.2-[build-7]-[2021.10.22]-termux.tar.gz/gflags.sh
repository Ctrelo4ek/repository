#!/system/bin/sh

# SHELL SCRIPT (SH)

name="gflags"
version="2.2.2 [Build 7] [2021.10.22]"

# 2.2.2 [Build 7] [2021.10.22]

source="Termux"

chown 0.0 "/system/lib/libgflags.so"
chmod 0644 "/system/lib/libgflags.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgflags.so"

chown 0.0 "/system/lib/libgflags_nothreads.so"
chmod 0644 "/system/lib/libgflags_nothreads.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgflags_nothreads.so"

chown 0.0 "/system/lib64/libgflags.so"
chmod 0644 "/system/lib64/libgflags.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgflags.so"

chown 0.0 "/system/lib64/libgflags_nothreads.so"
chmod 0644 "/system/lib64/libgflags_nothreads.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgflags_nothreads.so"

chown 0.2000 "/system/xbin/gflags_completions.sh"
chmod 0755 "/system/xbin/gflags_completions.sh"

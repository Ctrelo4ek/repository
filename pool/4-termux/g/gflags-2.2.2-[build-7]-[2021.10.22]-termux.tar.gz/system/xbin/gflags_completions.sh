#!/system/bin/bash

completion_word_index="$(( $# - 1 ))"
completion_word="${!completion_word_index}"

if [ -z "${completion_word}" ]; then
	exit 0
fi

binary_index="$(( $# - 2 ))"
binary="${!binary_index}"

if [ "${binary}" == "time" ] || [ "${binary}" == "env" ]; then
	parts=( ${COMP_LINE} )
	binary=${parts[1]}
fi

params=""

for (( i=1; i<=$(( $# - 3 )); ++i )); do 
	params="${params} \"${!i}\""
done

params="${params} --tab_completion_word \"${completion_word}\""

candidate="$( type -p ${binary} )"

if [ ! -z "${candidate}" ]; then
	eval "${candidate} 2>/dev/null ${params}"
elif [ -f "${binary}" ] && [ -x "${binary}" ]; then
	eval "${binary} 2>/dev/null ${params}"
fi

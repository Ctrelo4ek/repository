#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libcurl"
version="7.79.1 [2021.10.23]"

# 7.79.1 [2021.10.23]

source="Termux"
source_2="https://github.com/robertying/openssl-curl-android"

chown 0.0 "/system/lib/libcurl.so"
chmod 0644 "/system/lib/libcurl.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libcurl.so"

chown 0.2000 "/system/bin/curl-config"
chmod 0755 "/system/bin/curl-config"

chown -hR 0.0 "/system/etc/pkgconfig"
chmod -R 0644 "/system/etc/pkgconfig"

find "/system/etc/pkgconfig" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/pkgconfig" "/system/usr/share/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib64/pkgconfig"

chown 0.0 "/system/lib64/libcurl.so"
chmod 0644 "/system/lib64/libcurl.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libcurl.so"

# 7.79.1 [2021.10.23]

source_2="Termux Make"

chown 0.0 "/system/lib64/libhostname.so"
chmod 0644 "/system/lib64/libhostname.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libhostname.so"

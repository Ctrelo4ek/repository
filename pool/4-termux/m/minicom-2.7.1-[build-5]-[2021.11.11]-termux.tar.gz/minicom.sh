#!/system/bin/sh

# SHELL SCRIPT (SH)

name="minicom"
version="2.7.1 [Build 5]"

# 2.7.1 [Build 5]

source="Termux"

chown 0.2000 "/system/xbin/ascii-xfr"
chmod 0755 "/system/xbin/ascii-xfr"

chown 0.2000 "/system/xbin/minicom"
chmod 0755 "/system/xbin/minicom"

chown 0.2000 "/system/xbin/runscript"
chmod 0755 "/system/xbin/runscript"

chown 0.2000 "/system/xbin/xminicom"
chmod 0755 "/system/xbin/xminicom"

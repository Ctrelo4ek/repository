#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libass"
version="0.15.1 [2021.09.05]"

# 0.15.1 [2021.09.05]

source="Termux Make"

chown 0.0 "/system/lib/libass.so"
chmod 0644 "/system/lib/libass.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libass.so"

chown 0.0 "/system/lib64/libass.so"
chmod 0644 "/system/lib64/libass.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libass.so"

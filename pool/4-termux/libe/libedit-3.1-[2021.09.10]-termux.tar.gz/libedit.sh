#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libedit"
version="3.1 [2021.09.10]"

# 3.1 [2021.09.10]

source="Termux"

chown 0.0 "/system/lib/libedit.so"
chmod 0644 "/system/lib/libedit.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libedit.so"

chown 0.0 "/system/lib64/libedit.so"
chmod 0644 "/system/lib64/libedit.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libedit.so"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="yara"
version="4.1.0 [Build 2] [2021.10.24]"

# 4.1.0 [Build 2] [2021.10.24]

source="Termux"

chown 0.0 "/system/lib/libyara.so"
chmod 0644 "/system/lib/libyara.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libyara.so"

chown 0.0 "/system/lib64/libyara.so"
chmod 0644 "/system/lib64/libyara.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libyara.so"

chown 0.2000 "/system/xbin/yara"
chmod 0755 "/system/xbin/yara"

chown 0.2000 "/system/xbin/yarac"
chmod 0755 "/system/xbin/yarac"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="flac"
version="1.3.3 [Build 2] [2021.10.22]"

# 1.3.3 [Build 2] [2021.10.22]

source="Termux"

chown 0.2000 "/system/xbin/flac"
chmod 0755 "/system/xbin/flac"

chown 0.2000 "/system/xbin/metaflac"
chmod 0755 "/system/xbin/metaflac"

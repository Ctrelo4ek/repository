#!/system/bin/sh

# SHELL SCRIPT (SH)

name="openal-soft"
version="1.21.0"

# 1.21.0

source="Termux"

chown -hR 0.0 "/system/etc/openal"
chmod -R 0644 "/system/etc/openal"

find "/system/etc/openal" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/openal" "/system/usr/share/openal"

chown 0.0 "/system/lib/libopenal.so"
chmod 0644 "/system/lib/libopenal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libopenal.so"

chown 0.0 "/system/lib64/libopenal.so"
chmod 0644 "/system/lib64/libopenal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libopenal.so"

chown 0.2000 "/system/xbin/alrecord"
chmod 0755 "/system/xbin/alrecord"

chown 0.2000 "/system/xbin/altonegen"
chmod 0755 "/system/xbin/altonegen"

chown 0.2000 "/system/xbin/openal-info"
chmod 0755 "/system/xbin/openal-info"

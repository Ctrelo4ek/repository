#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libtirpc"
version="1.3.2 [2021.11.06]"

# 1.3.2 [2021.11.06]

source="Termux"

chown 0.0 "/system/etc/bindresvport.blacklist"
chmod 0644 "/system/etc/bindresvport.blacklist"

chown 0.0 "/system/etc/netconfig"
chmod 0644 "/system/etc/netconfig"

chown 0.0 "/system/lib/libtirpc.so"
chmod 0644 "/system/lib/libtirpc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libtirpc.so"

chown 0.0 "/system/lib64/libtirpc.so"
chmod 0644 "/system/lib64/libtirpc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libtirpc.so"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="sleuthkit"
version="4.11.1"

# 4.10.0

chown -hR 0.0 "/system/etc/tsk"
chmod -R 0644 "/system/etc/tsk"

find "/system/etc/tsk" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/tsk" "/system/usr/share/tsk"

chown 0.0 "/system/etc/yaffs2.config"
chmod 0644 "/system/etc/yaffs2.config"

chown 0.0 "/system/lib/libtsk.so"
chmod 0644 "/system/lib/libtsk.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libtsk.so"

chown 0.0 "/system/lib64/libtsk.so"
chmod 0644 "/system/lib64/libtsk.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libtsk.so"

chown 0.0 "/system/perl"
chmod 0755 "/system/perl"

chown 0.2000 "/system/perl/bin"
chmod 0755 "/system/perl/bin"

chown 0.2000 "/system/xbin/blkcalc"
chmod 0755 "/system/xbin/blkcalc"

chown 0.2000 "/system/xbin/blkcat"
chmod 0755 "/system/xbin/blkcat"

chown 0.2000 "/system/xbin/blkls"
chmod 0755 "/system/xbin/blkls"

chown 0.2000 "/system/xbin/blkstat"
chmod 0755 "/system/xbin/blkstat"

chown 0.2000 "/system/xbin/fcat"
chmod 0755 "/system/xbin/fcat"

chown 0.2000 "/system/xbin/ffind"
chmod 0755 "/system/xbin/ffind"

chown 0.2000 "/system/xbin/fiwalk"
chmod 0755 "/system/xbin/fiwalk"

chown 0.2000 "/system/xbin/fls"
chmod 0755 "/system/xbin/fls"

chown 0.2000 "/system/xbin/fsstat"
chmod 0755 "/system/xbin/fsstat"

chown 0.2000 "/system/xbin/hfind"
chmod 0755 "/system/xbin/hfind"

chown 0.2000 "/system/xbin/icat"
chmod 0755 "/system/xbin/icat"

chown 0.2000 "/system/xbin/ifind"
chmod 0755 "/system/xbin/ifind"

chown 0.2000 "/system/xbin/ils"
chmod 0755 "/system/xbin/ils"

chown 0.2000 "/system/xbin/img_cat"
chmod 0755 "/system/xbin/img_cat"

chown 0.2000 "/system/xbin/img_stat"
chmod 0755 "/system/xbin/img_stat"

chown 0.2000 "/system/xbin/istat"
chmod 0755 "/system/xbin/istat"

chown 0.2000 "/system/xbin/jcat"
chmod 0755 "/system/xbin/jcat"

chown 0.2000 "/system/xbin/jls"
chmod 0755 "/system/xbin/jls"

chown 0.2000 "/system/xbin/jpeg_extract"
chmod 0755 "/system/xbin/jpeg_extract"

chown 0.2000 "/system/xbin/mactime"
chmod 0755 "/system/xbin/mactime"

ln -s "../../xbin/mactime" "/system/perl/bin/mactime"

chown 0.2000 "/system/xbin/mmcat"
chmod 0755 "/system/xbin/mmcat"

chown 0.2000 "/system/xbin/mmls"
chmod 0755 "/system/xbin/mmls"

chown 0.2000 "/system/xbin/mmstat"
chmod 0755 "/system/xbin/mmstat"

chown 0.2000 "/system/xbin/pstat"
chmod 0755 "/system/xbin/pstat"

chown 0.2000 "/system/xbin/sigfind"
chmod 0755 "/system/xbin/sigfind"

chown 0.2000 "/system/xbin/sorter"
chmod 0755 "/system/xbin/sorter"

ln -s "../../xbin/sorter" "/system/perl/bin/sorter"

chown 0.2000 "/system/xbin/srch_strings"
chmod 0755 "/system/xbin/srch_strings"

chown 0.2000 "/system/xbin/tsk_comparedir"
chmod 0755 "/system/xbin/tsk_comparedir"

chown 0.2000 "/system/xbin/tsk_gettimes"
chmod 0755 "/system/xbin/tsk_gettimes"

chown 0.2000 "/system/xbin/tsk_loaddb"
chmod 0755 "/system/xbin/tsk_loaddb"

chown 0.2000 "/system/xbin/tsk_recover"
chmod 0755 "/system/xbin/tsk_recover"

chown 0.2000 "/system/xbin/usnjls"
chmod 0755 "/system/xbin/usnjls"

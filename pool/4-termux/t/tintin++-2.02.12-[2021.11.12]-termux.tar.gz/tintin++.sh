#!/system/bin/sh

# SHELL SCRIPT (SH)

name="tintin++"
version="2.02.04"

# 2.02.04

source="Termux"

chown 0.2000 "/system/xbin/tt++"
chmod 0755 "/system/xbin/tt++"

ln -s "tt++" "/system/xbin/tintin++"

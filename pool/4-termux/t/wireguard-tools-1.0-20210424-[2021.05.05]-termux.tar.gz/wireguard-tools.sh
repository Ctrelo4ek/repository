#!/system/bin/sh

# SHELL SCRIPT (SH)

name="wireguard-tools"
version="1.0-20210424 [2021.05.05]"

# 1.0-20210424 [2021.05.05]

source="Termux"
source_2="https://github.com/henriknelson/wireguard-tools-magisk-module"

chown 0.2000 "/system/xbin/wg"
chmod 0755 "/system/xbin/wg"

chown 0.2000 "/system/xbin/wg-quick"
chmod 0755 "/system/xbin/wg-quick"

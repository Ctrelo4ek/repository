# Set a configuration file path for tidy(1)
HTML_TIDY=${XDG_CONFIG_HOME:-$HOME/.config}/tidy/tidyrc
export HTML_TIDY

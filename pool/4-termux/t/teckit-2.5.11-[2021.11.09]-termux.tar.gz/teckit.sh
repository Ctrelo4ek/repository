#!/system/bin/sh

# SHELL SCRIPT (SH)

name="teckit"
version="2.5.11"

# 2.5.11

source="Termux"

chown 0.0 "/system/lib/libTECkit.so"
chmod 0644 "/system/lib/libTECkit.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libTECkit.so"

chown 0.0 "/system/lib/libTECkit_Compiler.so"
chmod 0644 "/system/lib/libTECkit_Compiler.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libTECkit_Compiler.so"

chown 0.0 "/system/lib64/libTECkit.so"
chmod 0644 "/system/lib64/libTECkit.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libTECkit.so"

chown 0.0 "/system/lib64/libTECkit_Compiler.so"
chmod 0644 "/system/lib64/libTECkit_Compiler.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libTECkit_Compiler.so"

chown 0.2000 "/system/xbin/sfconv"
chmod 0755 "/system/xbin/sfconv"

chown 0.2000 "/system/xbin/teckit_compile"
chmod 0755 "/system/xbin/teckit_compile"

chown 0.2000 "/system/xbin/txtconv"
chmod 0755 "/system/xbin/txtconv"

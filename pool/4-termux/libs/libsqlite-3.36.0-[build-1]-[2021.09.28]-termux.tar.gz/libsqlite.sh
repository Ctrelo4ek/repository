#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libsqlite"
version="3.36.0 [Build 1] [2021.09.28]"

# 3.28.0 [2020.05.06]

source="Android"

chown 0.0 "/system/lib/libsqlite.so"
chmod 0644 "/system/lib/libsqlite.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libsqlite.so"

chown 0.0 "/system/lib64/libsqlite.so"
chmod 0644 "/system/lib64/libsqlite.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libsqlite.so"

# 3.36.0 [Build 1] [2021.09.28]

source="Termux Make"

chown 0.0 "/system/lib/libsqlite3.so"
chmod 0644 "/system/lib/libsqlite3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libsqlite3.so"

chown 0.0 "/system/lib64/libsqlite3.so"
chmod 0644 "/system/lib64/libsqlite3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libsqlite3.so"

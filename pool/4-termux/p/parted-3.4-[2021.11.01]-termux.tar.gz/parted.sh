#!/system/bin/sh

# SHELL SCRIPT (SH)

name="parted"
version="3.4 [2021.11.01]"

# 3.4 [2021.11.01]

source="Termux"

chown 0.2000 "/system/xbin/parted"
chmod 0755 "/system/xbin/parted"

chown 0.2000 "/system/xbin/partprobe"
chmod 0755 "/system/xbin/partprobe"

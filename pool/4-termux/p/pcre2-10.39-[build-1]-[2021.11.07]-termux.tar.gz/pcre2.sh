#!/system/bin/sh

# SHELL SCRIPT (SH)

name="pcre2"
version="10.39 [Build-1] [2021.11.07]"

# 10.33 [2019.04.16]

source="Android"

chown 0.0 "/system/aarch64-linux-android"
chmod 0755 "/system/aarch64-linux-android"

chown 0.2000 "/system/aarch64-linux-android/bin"
chmod 0755 "/system/aarch64-linux-android/bin"

chown 0.0 "/system/aarch64-linux-android/lib"
chmod 0644 "/system/aarch64-linux-android/lib"

ln -s "lib" "/system/aarch64-linux-android/lib64"

chcon -hR u:object_r:system_lib_file:s0 "/system/aarch64-linux-android/lib"

chown -hR 0.0 "/system/lib/gcc"
chmod -R 0644 "/system/lib/gcc"

find "/system/lib/gcc" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../lib/gcc" "/system/aarch64-linux-android/lib/gcc"
ln -s "../lib/gcc" "/system/lib64/gcc"

chcon -hR u:object_r:system_file:s0 "/system/lib/gcc"

chown 0.0 "/system/lib/libpcre2.so"
chmod 0644 "/system/lib/libpcre2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libpcre2.so"

chown 0.0 "/system/lib64/libpcre2.so"
chmod 0644 "/system/lib64/libpcre2.so"

ln -s "../../../../lib64/libpcre2.so" "/system/lib/gcc/aarch64-linux-android/release/libpcre2.so"
ln -s "../../lib64/libpcre2.so" "/system/aarch64-linux-android/lib/libpcre2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpcre2.so"

# 10.39 [Build-1] [2021.11.07]

source_2="Termux"

chown 0.0 "/system/lib/libpcre2-16.so"
chmod 0644 "/system/lib/libpcre2-16.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libpcre2-16.so"

chown 0.0 "/system/lib/libpcre2-32.so"
chmod 0644 "/system/lib/libpcre2-32.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libpcre2-32.so"

chown 0.0 "/system/lib/libpcre2-8.so"
chmod 0644 "/system/lib4/libpcre2-8.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libpcre2-8.so"

# 10.36 [2020.12.04]

source_3="Termux Make"

chown 0.0 "/system/lib64/libpcre2-16.so"
chmod 0644 "/system/lib64/libpcre2-16.so"

ln -s "../../../../lib64/libpcre2-16.so" "/system/lib/gcc/aarch64-linux-android/release/libpcre2-16.so"
ln -s "../../lib64/libpcre2-16.so" "/system/aarch64-linux-android/lib/libpcre2-16.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpcre2-16.so"

chown 0.0 "/system/lib64/libpcre2-32.so"
chmod 0644 "/system/lib64/libpcre2-32.so"

ln -s "../../../../lib64/libpcre2-32.so" "/system/lib/gcc/aarch64-linux-android/release/libpcre2-32.so"
ln -s "../../lib64/libpcre2-32.so" "/system/aarch64-linux-android/lib/libpcre2-32.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpcre2-32.so"

chown 0.0 "/system/lib64/libpcre2-8.so"
chmod 0644 "/system/lib64/libpcre2-8.so"

ln -s "../../../../lib64/libpcre2-8.so" "/system/lib/gcc/aarch64-linux-android/release/libpcre2-8.so"
ln -s "../../lib64/libpcre2-8.so" "/system/aarch64-linux-android/lib/libpcre2-8.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpcre2-8.so"

chown 0.0 "/system/lib64/libpcre2-posix.so"
chmod 0644 "/system/lib64/libpcre2-posix.so"

ln -s "../../../../lib64/libpcre2-posix.so" "/system/lib/gcc/aarch64-linux-android/release/libpcre2-posix.so"
ln -s "../../lib64/libpcre2-posix.so" "/system/aarch64-linux-android/lib/libpcre2-posix.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpcre2-posix.so"

chown 0.2000 "/system/xbin/pcre2-config"
chmod 0755 "/system/xbin/pcre2-config"

ln -s "../../xbin/pcre2-config" "/system/aarch64-linux-android/bin/pcre2-config"

chown 0.2000 "/system/xbin/pcre2grep"
chmod 0755 "/system/xbin/pcre2grep"

ln -s "../../xbin/pcre2grep" "/system/aarch64-linux-android/bin/pcre2grep"

chown 0.2000 "/system/xbin/pcre2test"
chmod 0755 "/system/xbin/pcre2test"

ln -s "../../xbin/pcre2test" "/system/aarch64-linux-android/bin/pcre2test"

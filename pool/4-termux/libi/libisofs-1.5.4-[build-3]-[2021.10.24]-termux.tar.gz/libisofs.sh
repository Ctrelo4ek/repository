#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libisofs"
version="1.5.4 [Build 3] [2021.10.24]"

# 1.5.4 [Build 3] [2021.10.24]

source="Termux"

chown 0.0 "/system/lib/libisofs.so"
chmod 0644 "/system/lib/libisofs.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libisofs.so"

chown 0.0 "/system/lib64/libisofs.so"
chmod 0644 "/system/lib64/libisofs.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libisofs.so"

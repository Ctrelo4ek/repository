#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libice"
version="1.0.10"

# 1.0.10

source="Termux"

chown 0.0 "/system/lib/libICE.so"
chmod 0644 "/system/lib/libICE.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libICE.so"

chown 0.0 "/system/lib64/libICE.so"
chmod 0644 "/system/lib64/libICE.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libICE.so"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="pv"
version="1.6.20 [2021.09.13]"

# 1.6.20 [2021.09.13]

source="Termux Make"

chown 0.2000 "/system/xbin/pv"
chmod 0755 "/system/xbin/pv"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="progress"
version="0.16 [2021.09.06]"

# 0.16 [2021.09.06]

source="Termux Make"
source_2="https://github.com/henriknelson/progress-magisk-module"

chown 0.2000 "/system/xbin/progress"
chmod 0755 "/system/xbin/progress"

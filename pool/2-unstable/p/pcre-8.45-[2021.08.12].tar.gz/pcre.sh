#!/system/bin/sh

# SHELL SCRIPT (SH)

name="pcre"
version="8.44 [2020.02.12]"

# 8.43 [2019.02.23]

source="Android"

chown 0.0 "/system/aarch64-linux-android"
chmod 0755 "/system/aarch64-linux-android"

chown 0.2000 "/system/aarch64-linux-android/bin"
chmod 0755 "/system/aarch64-linux-android/bin"

chown 0.0 "/system/aarch64-linux-android/lib"
chmod 0644 "/system/aarch64-linux-android/lib"

ln -s "lib" "/system/aarch64-linux-android/lib64"

chcon -hR u:object_r:system_lib_file:s0 "/system/aarch64-linux-android/lib"

chown -hR 0.0 "/system/lib/gcc"
chmod -R 0644 "/system/lib/gcc"

find "/system/lib/gcc" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../lib/gcc" "/system/aarch64-linux-android/lib/gcc"
ln -s "../lib/gcc" "/system/lib64/gcc"

chcon -hR u:object_r:system_file:s0 "/system/lib/gcc"

chown 0.0 "/system/lib64/libpcrecpp.so"
chmod 0644 "/system/lib64/libpcrecpp.so"

ln -s "../../../../lib64/libpcrecpp.so" "/system/lib/gcc/aarch64-linux-android/release/libpcrecpp.so"
ln -s "../../lib64/libpcrecpp.so" "/system/aarch64-linux-android/lib/libpcrecpp.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpcrecpp.so"

# 8.44 [2020.02.12]

source_2="Termux"

chown 0.0 "/system/lib/libpcre.so"
chmod 0644 "/system/lib/libpcre.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libpcre.so"

chown 0.0 "/system/lib/libpcrecpp.so"
chmod 0644 "/system/lib/libpcrecpp.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libpcrecpp.so"

chown 0.0 "/system/lib/libpcreposix.so"
chmod 0644 "/system/lib/libpcreposix.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libpcreposix.so"

chown 0.0 "/system/lib64/libpcreposix.so"
chmod 0644 "/system/lib64/libpcreposix.so"

ln -s "../../../../lib64/libpcreposix.so" "/system/lib/gcc/aarch64-linux-android/release/libpcreposix.so"
ln -s "../../lib64/libpcreposix.so" "/system/aarch64-linux-android/lib/libpcreposix.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpcreposix.so"

# 8.44 [2020.02.12]

source_3="Termux Make"

chown 0.0 "/system/lib64/libpcre.so"
chmod 0644 "/system/lib64/libpcre.so"

ln -s "../../../../lib64/libpcre.so" "/system/lib/gcc/aarch64-linux-android/release/libpcre.so"
ln -s "../../lib64/libpcre.so" "/system/aarch64-linux-android/lib/libpcre.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpcre.so"

chown 0.0 "/system/lib64/libpcre16.so"
chmod 0644 "/system/lib64/libpcre16.so"

ln -s "../../../../lib64/libpcre16.so" "/system/lib/gcc/aarch64-linux-android/release/libpcre16.so"
ln -s "../../lib64/libpcre16.so" "/system/aarch64-linux-android/lib/libpcre16.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpcre16.so"

chown 0.0 "/system/lib64/libpcre32.so"
chmod 0644 "/system/lib64/libpcre32.so"

ln -s "../../../../lib64/libpcre32.so" "/system/lib/gcc/aarch64-linux-android/release/libpcre32.so"
ln -s "../../lib64/libpcre32.so" "/system/aarch64-linux-android/lib/libpcre32.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpcre32.so"

chown 0.2000 "/system/xbin/pcre-config"
chmod 0755 "/system/xbin/pcre-config"

ln -s "../../xbin/pcre-config" "/system/aarch64-linux-android/bin/pcre-config"

chown 0.2000 "/system/xbin/pcre_scanner_unittest"
chmod 0755 "/system/xbin/pcre_scanner_unittest"

chown 0.2000 "/system/xbin/pcre_stringpiece_unittest"
chmod 0755 "/system/xbin/pcre_stringpiece_unittest"

chown 0.2000 "/system/xbin/pcrecpp_unittest"
chmod 0755 "/system/xbin/pcrecpp_unittest"

chown 0.2000 "/system/xbin/pcregrep"
chmod 0755 "/system/xbin/pcregrep"

ln -s "../../xbin/pcregrep" "/system/aarch64-linux-android/bin/pcregrep"

chown 0.2000 "/system/xbin/pcretest"
chmod 0755 "/system/xbin/pcretest"

ln -s "../../xbin/pcretest" "/system/aarch64-linux-android/bin/pcretest"

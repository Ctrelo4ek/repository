#!/system/bin/sh

# SHELL SCRIPT (SH)

name="secilc [selinux]"
version="3.1 [2021.08.01]"

# 3.1 [2021.08.01]

source="Termux Make"

chown 0.0 "/system/etc/selinux/plat_sepolicy.cil"
chmod 0644 "/system/etc/selinux/plat_sepolicy.cil"

chcon -hR u:object_r:sepolicy_file:s0 "/system/etc/selinux/plat_sepolicy.cil"

chown 0.2000 "/system/xbin/secilc"
chmod 0755 "/system/xbin/secilc"

chown 0.2000 "/system/xbin/secil2conf"
chmod 0755 "/system/xbin/secil2conf"

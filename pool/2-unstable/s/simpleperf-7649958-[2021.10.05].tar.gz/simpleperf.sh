#!/system/bin/sh

# SHELL SCRIPT (SH)

name="simpleperf"
version="7649958 [2021.10.05]"

# 20210619 [2021.06.19]

source="Android"

chown 0.2000 "/system/bin/simpleperf"
chmod 0755 "/system/bin/simpleperf"

# 7649958 [2021.10.05]

chown 0.2000 "/system/xbin/simpleperf"
chmod 0755 "/system/xbin/simpleperf"

chown 0.2000 "/system/xbin/simpleperf32"
chmod 0755 "/system/xbin/simpleperf32"

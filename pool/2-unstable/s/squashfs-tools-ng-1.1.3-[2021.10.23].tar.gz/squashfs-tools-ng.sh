#!/system/bin/sh

# SHELL SCRIPT (SH)

name="squashfs-tools-ng"
version="1.1.3 [2021.10.23]"

# 1.1.3 [2021.10.23]

source="Termux Make"

chown 0.0 "/system/lib64/libsquashfs.so"
chmod 0644 "/system/lib64/libsquashfs.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libsquashfs.so"

chown 0.2000 "/system/xbin/fstree_fuzz"
chmod 0755 "/system/xbin/fstree_fuzz"

chown 0.2000 "/system/xbin/gensquashfs"
chmod 0755 "/system/xbin/gensquashfs"

ln -s "gensquashfs" "/system/xbin/mkfs.shfs"

chown 0.2000 "/system/xbin/list_files"
chmod 0755 "/system/xbin/list_files"

chown 0.2000 "/system/xbin/mk42sqfs"
chmod 0755 "/system/xbin/mk42sqfs"

ln -s "mk42sqfs" "/system/xbin/mkfs.42sqfs"

chown 0.2000 "/system/xbin/mknastyfs"
chmod 0755 "/system/xbin/mknastyfs"

ln -s "mknastyfs" "/system/xbin/mkfs.nastyfs"

chown 0.2000 "/system/xbin/rdsquashfs"
chmod 0755 "/system/xbin/rdsquashfs"

chown 0.2000 "/system/xbin/sqfs2tar"
chmod 0755 "/system/xbin/sqfs2tar"

chown 0.2000 "/system/xbin/sqfsbrowse"
chmod 0755 "/system/xbin/sqfsbrowse"

chown 0.2000 "/system/xbin/sqfsdiff"
chmod 0755 "/system/xbin/sqfsdiff"

chown 0.2000 "/system/xbin/tar_fuzz"
chmod 0755 "/system/xbin/tar_fuzz"

ln -s "tar_fuzz" "/system/xbin/tar2fuzz"

chown 0.2000 "/system/xbin/tar2sqfs"
chmod 0755 "/system/xbin/tar2sqfs"

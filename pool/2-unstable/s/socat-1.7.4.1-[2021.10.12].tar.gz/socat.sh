#!/system/bin/sh

# SHELL SCRIPT (SH)

name="socat"
version="1.7.4.1 [2021.10.12]"

# 1.7.4.1 [2021.10.12]

source="Termux Make"

chown 0.2000 "/system/xbin/filan"
chmod 0755 "/system/xbin/filan"

chown 0.2000 "/system/xbin/procan"
chmod 0755 "/system/xbin/procan"

chown 0.2000 "/system/xbin/socat"
chmod 0755 "/system/xbin/socat"

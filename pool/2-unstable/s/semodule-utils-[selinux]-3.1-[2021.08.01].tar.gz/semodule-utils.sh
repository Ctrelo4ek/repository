#!/system/bin/sh

# SHELL SCRIPT (SH)

name="semodule-utils [selinux]"
version="3.1 [2021.08.01]"

# 3.1 [2021.08.01]

source="Termux Make"

chown 0.2000 "/system/xbin/semodule_expand"
chmod 0755 "/system/xbin/semodule_expand"

chown 0.2000 "/system/xbin/semodule_link"
chmod 0755 "/system/xbin/semodule_link"

chown 0.2000 "/system/xbin/semodule_package"
chmod 0755 "/system/xbin/semodule_package"

chown 0.2000 "/system/xbin/semodule_unpackage"
chmod 0755 "/system/xbin/semodule_unpackage"

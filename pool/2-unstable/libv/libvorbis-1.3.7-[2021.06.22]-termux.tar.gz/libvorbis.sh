#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libvorbis"
version="1.3.7 [2021.06.22]"

# 1.3.7 [2021.06.22]

source="Termux"

chown 0.0 "/system/lib/libvorbis.so"
chmod 0644 "/system/lib/libvorbis.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libvorbis.so"

chown 0.0 "/system/lib/libvorbisenc.so"
chmod 0644 "/system/lib/libvorbisenc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libvorbisenc.so"

chown 0.0 "/system/lib/libvorbisfile.so"
chmod 0644 "/system/lib/libvorbisfile.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libvorbisfile.so"

chown 0.0 "/system/lib64/libvorbis.so"
chmod 0644 "/system/lib64/libvorbis.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libvorbis.so"

chown 0.0 "/system/lib64/libvorbisenc.so"
chmod 0644 "/system/lib64/libvorbisenc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libvorbisenc.so"

chown 0.0 "/system/lib64/libvorbisfile.so"
chmod 0644 "/system/lib64/libvorbisfile.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libvorbisfile.so"

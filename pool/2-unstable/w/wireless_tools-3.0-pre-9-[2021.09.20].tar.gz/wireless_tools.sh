#!/system/bin/sh

# SHELL SCRIPT (SH)

name="wireless_tools"
version="3.0 Pre 9 [2021.09.20]"

# 3.0 Pre 9 [2021.09.20]

source="Termux Make"

chown 0.0 "/system/etc/iftab"
chmod 0644 "/system/etc/iftab"

chown 0.2000 "/system/xbin/ifrename"
chmod 0755 "/system/xbin/ifrename"

chown 0.2000 "/system/xbin/iwconfig"
chmod 0755 "/system/xbin/iwconfig"

chcon -hR u:object_r:wcnss_service_exec:s0 "/system/xbin/iwconfig"

chown 0.2000 "/system/xbin/iwevent"
chmod 0755 "/system/xbin/iwevent"

chown 0.2000 "/system/xbin/iwgetid"
chmod 0755 "/system/xbin/iwgetid"

chown 0.2000 "/system/xbin/iwlist"
chmod 0755 "/system/xbin/iwlist"

chown 0.2000 "/system/xbin/iwmulticall"
chmod 0755 "/system/xbin/iwmulticall"

chown 0.2000 "/system/xbin/iwpriv"
chmod 0755 "/system/xbin/iwpriv"

chown 0.2000 "/system/xbin/iwspy"
chmod 0755 "/system/xbin/iwspy"

chown 0.2000 "/system/xbin/macaddr"
chmod 0755 "/system/xbin/macaddr"

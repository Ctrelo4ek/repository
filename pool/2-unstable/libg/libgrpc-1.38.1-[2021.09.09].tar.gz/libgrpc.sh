#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libgrpc"
version="1.38.1 [2021.09.09]"

# 1.32.0

source="Termux"

chown -hR 0.0 "/system/etc/grpc"
chmod -R 0644 "/system/etc/grpc"

find "/system/etc/grpc" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/grpc" "/system/usr/share/grpc"

chown -hR 0.0 "/system/etc/ssl"
chmod -R 0644 "/system/etc/ssl"

find "/system/etc/ssl" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../security/cacerts" "/system/etc/ssl/certs"
ln -s "../ssl/roots.pem" "/system/etc/grpc/roots.pem"

ln -s "../../etc/ssl" "/system/usr/share/ssl"
ln -s "../../etc/ssl" "/system/usr/share/tls"

chown 0.0 "/system/lib/libabsl_bad_optional_access.so"
chmod 0644 "/system/lib/libabsl_bad_optional_access.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_bad_optional_access.so"

chown 0.0 "/system/lib/libabsl_bad_variant_access.so"
chmod 0644 "/system/lib/libabsl_bad_variant_access.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_bad_variant_access.so"

chown 0.0 "/system/lib/libabsl_base.so"
chmod 0644 "/system/lib/libabsl_base.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_base.so"

chown 0.0 "/system/lib/libabsl_city.so"
chmod 0644 "/system/lib/libabsl_city.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_city.so"

chown 0.0 "/system/lib/libabsl_civil_time.so"
chmod 0644 "/system/lib/libabsl_civil_time.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_civil_time.so"

chown 0.0 "/system/lib/libabsl_cord.so"
chmod 0644 "/system/lib/libabsl_cord.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_cord.so"

chown 0.0 "/system/lib/libabsl_debugging_internal.so"
chmod 0644 "/system/lib/libabsl_debugging_internal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_debugging_internal.so"

chown 0.0 "/system/lib/libabsl_demangle_internal.so"
chmod 0644 "/system/lib/libabsl_demangle_internal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_demangle_internal.so"

chown 0.0 "/system/lib/libabsl_dynamic_annotations.so"
chmod 0644 "/system/lib/libabsl_dynamic_annotations.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_dynamic_annotations.so"

chown 0.0 "/system/lib/libabsl_exponential_biased.so"
chmod 0644 "/system/lib/libabsl_exponential_biased.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_exponential_biased.so"

chown 0.0 "/system/lib/libabsl_graphcycles_internal.so"
chmod 0644 "/system/lib/libabsl_graphcycles_internal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_graphcycles_internal.so"

chown 0.0 "/system/lib/libabsl_hash.so"
chmod 0644 "/system/lib/libabsl_hash.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_hash.so"

chown 0.0 "/system/lib/libabsl_hashtablez_sampler.so"
chmod 0644 "/system/lib/libabsl_hashtablez_sampler.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_hashtablez_sampler.so"

chown 0.0 "/system/lib/libabsl_int128.so"
chmod 0644 "/system/lib/libabsl_int128.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_int128.so"

chown 0.0 "/system/lib/libabsl_log_severity.so"
chmod 0644 "/system/lib/libabsl_log_severity.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_log_severity.so"

chown 0.0 "/system/lib/libabsl_malloc_internal.so"
chmod 0644 "/system/lib/libabsl_malloc_internal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_malloc_internal.so"

chown 0.0 "/system/lib/libabsl_raw_hash_set.so"
chmod 0644 "/system/lib/libabsl_raw_hash_set.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_raw_hash_set.so"

chown 0.0 "/system/lib/libabsl_raw_logging_internal.so"
chmod 0644 "/system/lib/libabsl_raw_logging_internal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_raw_logging_internal.so"

chown 0.0 "/system/lib/libabsl_spinlock_wait.so"
chmod 0644 "/system/lib/libabsl_spinlock_wait.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_spinlock_wait.so"

chown 0.0 "/system/lib/libabsl_stacktrace.so"
chmod 0644 "/system/lib/libabsl_stacktrace.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_stacktrace.so"

chown 0.0 "/system/lib/libabsl_status.so"
chmod 0644 "/system/lib/libabsl_status.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_status.so"

chown 0.0 "/system/lib/libabsl_str_format_internal.so"
chmod 0644 "/system/lib/libabsl_str_format_internal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_str_format_internal.so"

chown 0.0 "/system/lib/libabsl_strings_internal.so"
chmod 0644 "/system/lib/libabsl_strings_internal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_strings_internal.so"

chown 0.0 "/system/lib/libabsl_strings.so"
chmod 0644 "/system/lib/libabsl_strings.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_strings.so"

chown 0.0 "/system/lib/libabsl_symbolize.so"
chmod 0644 "/system/lib/libabsl_symbolize.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_symbolize.so"

chown 0.0 "/system/lib/libabsl_synchronization.so"
chmod 0644 "/system/lib/libabsl_synchronization.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_synchronization.so"

chown 0.0 "/system/lib/libabsl_throw_delegate.so"
chmod 0644 "/system/lib/libabsl_throw_delegate.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_throw_delegate.so"

chown 0.0 "/system/lib/libabsl_time_zone.so"
chmod 0644 "/system/lib/libabsl_time_zone.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_time_zone.so"

chown 0.0 "/system/lib/libabsl_time.so"
chmod 0644 "/system/lib/libabsl_time.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libabsl_time.so"

chown 0.0 "/system/lib/libaddress_sorting.so"
chmod 0644 "/system/lib/libaddress_sorting.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libaddress_sorting.so"

chown 0.0 "/system/lib/libgpr.so"
chmod 0644 "/system/lib/libgpr.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgpr.so"

chown 0.0 "/system/lib/libgrpc_plugin_support.so"
chmod 0644 "/system/lib/libgrpc_plugin_support.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgrpc_plugin_support.so"

chown 0.0 "/system/lib/libgrpc_unsecure.so"
chmod 0644 "/system/lib/libgrpc_unsecure.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgrpc_unsecure.so"

chown 0.0 "/system/lib/libgrpc.so"
chmod 0644 "/system/lib/libgrpc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgrpc.so"

chown 0.0 "/system/lib/libgrpc++_alts.so"
chmod 0644 "/system/lib/libgrpc++_alts.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgrpc++_alts.so"

chown 0.0 "/system/lib/libgrpc++_error_details.so"
chmod 0644 "/system/lib/libgrpc++_error_details.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgrpc++_error_details.so"

chown 0.0 "/system/lib/libgrpc++_reflection.so"
chmod 0644 "/system/lib/libgrpc++_reflection.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgrpc++_reflection.so"

chown 0.0 "/system/lib/libgrpc++_unsecure.so"
chmod 0644 "/system/lib/libgrpc++_unsecure.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgrpc++_unsecure.so"

chown 0.0 "/system/lib/libgrpc++.so"
chmod 0644 "/system/lib/libgrpc++.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgrpc++.so"

chown 0.0 "/system/lib/libgrpcpp_channelz.so"
chmod 0644 "/system/lib/libgrpcpp_channelz.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgrpcpp_channelz.so"

chown 0.0 "/system/lib/libre2.so"
chmod 0644 "/system/lib/libre2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libre2.so"

chown 0.0 "/system/lib/libupb.so"
chmod 0644 "/system/lib/libupb.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libupb.so"

# 1.38.1 [2021.09.09]
 
source_2="Termux Make"

chown 0.0 "/system/lib64/libabsl_bad_optional_access.so"
chmod 0644 "/system/lib64/libabsl_bad_optional_access.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_bad_optional_access.so"

chown 0.0 "/system/lib64/libabsl_bad_variant_access.so"
chmod 0644 "/system/lib64/libabsl_bad_variant_access.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_bad_variant_access.so"

chown 0.0 "/system/lib64/libabsl_base.so"
chmod 0644 "/system/lib64/libabsl_base.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_base.so"

chown 0.0 "/system/lib64/libabsl_city.so"
chmod 0644 "/system/lib64/libabsl_city.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_city.so"

chown 0.0 "/system/lib64/libabsl_civil_time.so"
chmod 0644 "/system/lib64/libabsl_civil_time.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_civil_time.so"

chown 0.0 "/system/lib64/libabsl_cord.so"
chmod 0644 "/system/lib64/libabsl_cord.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_cord.so"

chown 0.0 "/system/lib64/libabsl_debugging_internal.so"
chmod 0644 "/system/lib64/libabsl_debugging_internal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_debugging_internal.so"

chown 0.0 "/system/lib64/libabsl_demangle_internal.so"
chmod 0644 "/system/lib64/libabsl_demangle_internal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_demangle_internal.so"

chown 0.0 "/system/lib64/libabsl_dynamic_annotations.so"
chmod 0644 "/system/lib64/libabsl_dynamic_annotations.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_dynamic_annotations.so"

chown 0.0 "/system/lib64/libabsl_exponential_biased.so"
chmod 0644 "/system/lib64/libabsl_exponential_biased.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_exponential_biased.so"

chown 0.0 "/system/lib64/libabsl_graphcycles_internal.so"
chmod 0644 "/system/lib64/libabsl_graphcycles_internal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_graphcycles_internal.so"

chown 0.0 "/system/lib64/libabsl_hash.so"
chmod 0644 "/system/lib64/libabsl_hash.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_hash.so"

chown 0.0 "/system/lib64/libabsl_hashtablez_sampler.so"
chmod 0644 "/system/lib64/libabsl_hashtablez_sampler.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_hashtablez_sampler.so"

chown 0.0 "/system/lib64/libabsl_int128.so"
chmod 0644 "/system/lib64/libabsl_int128.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_int128.so"

chown 0.0 "/system/lib64/libabsl_log_severity.so"
chmod 0644 "/system/lib64/libabsl_log_severity.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_log_severity.so"

chown 0.0 "/system/lib64/libabsl_malloc_internal.so"
chmod 0644 "/system/lib64/libabsl_malloc_internal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_malloc_internal.so"

chown 0.0 "/system/lib64/libabsl_raw_hash_set.so"
chmod 0644 "/system/lib64/libabsl_raw_hash_set.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_raw_hash_set.so"

chown 0.0 "/system/lib64/libabsl_raw_logging_internal.so"
chmod 0644 "/system/lib64/libabsl_raw_logging_internal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_raw_logging_internal.so"

chown 0.0 "/system/lib64/libabsl_spinlock_wait.so"
chmod 0644 "/system/lib64/libabsl_spinlock_wait.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_spinlock_wait.so"

chown 0.0 "/system/lib64/libabsl_stacktrace.so"
chmod 0644 "/system/lib64/libabsl_stacktrace.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_stacktrace.so"

chown 0.0 "/system/lib64/libabsl_status.so"
chmod 0644 "/system/lib64/libabsl_status.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_status.so"

chown 0.0 "/system/lib64/libabsl_str_format_internal.so"
chmod 0644 "/system/lib64/libabsl_str_format_internal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_str_format_internal.so"

chown 0.0 "/system/lib64/libabsl_strings_internal.so"
chmod 0644 "/system/lib64/libabsl_strings_internal.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_strings_internal.so"

chown 0.0 "/system/lib64/libabsl_strings.so"
chmod 0644 "/system/lib64/libabsl_strings.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_strings.so"

chown 0.0 "/system/lib64/libabsl_symbolize.so"
chmod 0644 "/system/lib64/libabsl_symbolize.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_symbolize.so"

chown 0.0 "/system/lib64/libabsl_synchronization.so"
chmod 0644 "/system/lib64/libabsl_synchronization.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_synchronization.so"

chown 0.0 "/system/lib64/libabsl_throw_delegate.so"
chmod 0644 "/system/lib64/libabsl_throw_delegate.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_throw_delegate.so"

chown 0.0 "/system/lib64/libabsl_time_zone.so"
chmod 0644 "/system/lib64/libabsl_time_zone.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_time_zone.so"

chown 0.0 "/system/lib64/libabsl_time.so"
chmod 0644 "/system/lib64/libabsl_time.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libabsl_time.so"

chown 0.0 "/system/lib64/libaddress_sorting.so"
chmod 0644 "/system/lib64/libaddress_sorting.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libaddress_sorting.so"

chown 0.0 "/system/lib64/libgpr.so"
chmod 0644 "/system/lib64/libgpr.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgpr.so"

chown 0.0 "/system/lib64/libgrpc_plugin_support.so"
chmod 0644 "/system/lib64/libgrpc_plugin_support.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgrpc_plugin_support.so"

chown 0.0 "/system/lib64/libgrpc_unsecure.so"
chmod 0644 "/system/lib64/libgrpc_unsecure.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgrpc_unsecure.so"

chown 0.0 "/system/lib64/libgrpc.so"
chmod 0644 "/system/lib64/libgrpc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgrpc.so"

chown 0.0 "/system/lib64/libgrpc++_alts.so"
chmod 0644 "/system/lib64/libgrpc++_alts.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgrpc++_alts.so"

chown 0.0 "/system/lib64/libgrpc++_error_details.so"
chmod 0644 "/system/lib64/libgrpc++_error_details.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgrpc++_error_details.so"

chown 0.0 "/system/lib64/libgrpc++_reflection.so"
chmod 0644 "/system/lib64/libgrpc++_reflection.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgrpc++_reflection.so"

chown 0.0 "/system/lib64/libgrpc++_unsecure.so"
chmod 0644 "/system/lib64/libgrpc++_unsecure.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgrpc++_unsecure.so"

chown 0.0 "/system/lib64/libgrpc++.so"
chmod 0644 "/system/lib64/libgrpc++.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgrpc++.so"

chown 0.0 "/system/lib64/libgrpcpp_channelz.so"
chmod 0644 "/system/lib64/libgrpcpp_channelz.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgrpcpp_channelz.so"

chown 0.0 "/system/lib64/libre2.so"
chmod 0644 "/system/lib64/libre2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libre2.so"

chown 0.0 "/system/lib64/libupb.so"
chmod 0644 "/system/lib64/libupb.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libupb.so"

chown 0.2000 "/system/xbin/grpc_cpp_plugin"
chmod 0755 "/system/xbin/grpc_cpp_plugin"

chown 0.2000 "/system/xbin/grpc_csharp_plugin"
chmod 0755 "/system/xbin/grpc_csharp_plugin"

chown 0.2000 "/system/xbin/grpc_node_plugin"
chmod 0755 "/system/xbin/grpc_node_plugin"

chown 0.2000 "/system/xbin/grpc_objective_c_plugin"
chmod 0755 "/system/xbin/grpc_objective_c_plugin"

chown 0.2000 "/system/xbin/grpc_php_plugin"
chmod 0755 "/system/xbin/grpc_php_plugin"

chown 0.2000 "/system/xbin/grpc_python_plugin"
chmod 0755 "/system/xbin/grpc_python_plugin"

chown 0.2000 "/system/xbin/grpc_ruby_plugin"
chmod 0755 "/system/xbin/grpc_ruby_plugin"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libgmp"
version="6.2.1"

# 6.2.1

source="Termux"

chown 0.0 "/system/aarch64-linux-android"
chmod 0755 "/system/aarch64-linux-android"

chown 0.0 "/system/aarch64-linux-android/lib"
chmod 0644 "/system/aarch64-linux-android/lib"

ln -s "lib" "/system/aarch64-linux-android/lib64"

chcon -hR u:object_r:system_lib_file:s0 "/system/aarch64-linux-android/lib"

chown -hR 0.0 "/system/lib/gcc"
chmod -R 0644 "/system/lib/gcc"

find "/system/lib/gcc" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../lib/gcc" "/system/aarch64-linux-android/lib/gcc"
ln -s "../lib/gcc" "/system/lib64/gcc"

chcon -hR u:object_r:system_file:s0 "/system/lib/gcc"

chown 0.0 "/system/lib/libgmp.so"
chmod 0644 "/system/lib/libgmp.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgmp.so"

chown 0.0 "/system/lib/libgmpxx.so"
chmod 0644 "/system/lib/libgmpxx.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgmpxx.so"

chown 0.0 "/system/lib64/libgmp.so"
chmod 0644 "/system/lib64/libgmp.so"

ln -s "../../../../lib64/libgmp.so" "/system/lib/gcc/aarch64-linux-android/release/libgmp.so"
ln -s "../../lib64/libgmp.so" "/system/aarch64-linux-android/lib/libgmp.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgmp.so"

chown 0.0 "/system/lib64/libgmpxx.so"
chmod 0644 "/system/lib64/libgmpxx.so"

ln -s "../../../../lib64/libgmpxx.so" "/system/lib/gcc/aarch64-linux-android/release/libgmpxx.so"
ln -s "../../lib64/libgmpxx.so" "/system/aarch64-linux-android/lib/libgmpxx.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgmpxx.so"

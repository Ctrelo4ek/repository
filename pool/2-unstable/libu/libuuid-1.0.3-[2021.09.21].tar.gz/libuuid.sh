#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libuuid"
version="1.0.3 [2021.09.21]"

# 1.0.3 [Build 4] [2020.07.05]

source="Termux"

chown 0.0 "/system/lib/libuuid.so"
chmod 0644 "/system/lib/libuuid.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libuuid.so"

# 1.0.3 [2021.09.21]

source_2="Termux Make"

chown 0.0 "/system/lib64/libuuid.so"
chmod 0644 "/system/lib64/libuuid.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libuuid.so"

chown 0.2000 "/system/xbin/test_uuid"
chmod 0755 "/system/xbin/test_uuid"

chown 0.2000 "/system/xbin/uuid_time"
chmod 0755 "/system/xbin/uuid_time"

chown 0.2000 "/system/xbin/uuidd"
chmod 0755 "/system/xbin/uuidd"

chcon -hR u:object_r:uuidd_exec:s0 "/system/xbin/uuidd"

chown 0.2000 "/system/xbin/uuidgen"
chmod 0755 "/system/xbin/uuidgen"

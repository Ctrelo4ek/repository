#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libuv"
version="1.42.0 [Build 1] [2021.09.20]"

# 1.42.0 [Build 1] [2021.09.20]

source="Termux"

chown -hR 0.0 "/system/lib/modules"
chmod -R 0644 "/system/lib/modules"

find "/system/lib/modules" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/modules"

chown 0.0 "/system/lib/libuv.so"
chmod 0644 "/system/lib/libuv.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libuv.so"

chown 0.0 "/system/lib64/libuv.so"
chmod 0644 "/system/lib64/libuv.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libuv.so"

#!/data/data/com.termux/files/usr/bin/sh
if [ -f "$HOME/.mpdscribble/mpdscribble.conf" ]; then CONFIG="$HOME/.mpdscribble/mpdscribble.conf"; else CONFIG="$PREFIX/etc/mpdscribble.conf"; fi
exec mpdscribble -D --log /proc/self/fd/1 --conf $CONFIG

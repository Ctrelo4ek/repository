#!/system/bin/sh

# SHELL SCRIPT (SH)

name="msmtp"
version="1.8.17 [2021.10.16]"

# 1.8.17 [2021.10.16]

source="Termux Make"

chown 0.0 "/system/etc/aliases"
chmod 0644 "/system/etc/aliases"

chown 0.0 "/system/etc/msmtprc"
chmod 0644 "/system/etc/msmtprc"

chown 0.2000 "/system/xbin/msmtp"
chmod 0755 "/system/xbin/msmtp"

ln -s "msmtp" "/system/xbin/sendmail"

chown 0.2000 "/system/xbin/msmtpd"
chmod 0755 "/system/xbin/msmtpd"

chcon -hR u:object_r:msmtpd_exec:s0 "/system/xbin/msmtpd"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="minizip-ng"
version="3.0.3 [2021.09.11]"

# 3.0.3 [2021.09.11]

source="Termux Make"

chown -hR 0.0 "/system/etc/pkgconfig"
chmod -R 0644 "/system/etc/pkgconfig"

find "/system/etc/pkgconfig" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/pkgconfig" "/system/usr/share/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib64/pkgconfig"

chown 0.0 "/system/lib64/libminizip.so"
chmod 0644 "/system/lib64/libminizip.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libminizip.so"

chown 0.2000 "/system/xbin/minizip"
chmod 0755 "/system/xbin/minizip"

chown 0.2000 "/system/xbin/zip_fuzzer"
chmod 0755 "/system/xbin/zip_fuzzer"

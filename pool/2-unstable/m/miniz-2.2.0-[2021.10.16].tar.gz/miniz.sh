#!/system/bin/sh

# SHELL SCRIPT (SH)

name="miniz"
version="2.2.0 [2021.10.16]"

# 2.2.0 [2021.10.16]

source="Termux Make"

chown 0.0 "/system/lib64/libminiz.so"
chmod 0644 "/system/lib64/libminiz.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libminiz.so"

chown 0.2000 "/system/xbin/miniz"
chmod 0755 "/system/xbin/miniz"

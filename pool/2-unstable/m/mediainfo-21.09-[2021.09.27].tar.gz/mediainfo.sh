#!/system/bin/sh

# SHELL SCRIPT (SH)

name="mediainfo"
version="21.09 [2021.09.27]"

# 21.09 [2021.09.27]

source="Termux Make"

chown 0.2000 "/system/xbin/mediainfo"
chmod 0755 "/system/xbin/mediainfo"

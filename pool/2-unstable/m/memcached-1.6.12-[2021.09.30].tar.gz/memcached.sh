#!/system/bin/sh

# SHELL SCRIPT (SH)

name="memcached"
version="1.6.12 [2021.09.30]"

# 1.6.12 [2021.09.30]

source="Termux Make"

chown 0.2000 "/system/xbin/memcached"
chmod 0755 "/system/xbin/memcached"

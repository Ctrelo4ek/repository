#!/system/bin/sh

# SHELL SCRIPT (SH)

name="mkbootimg"
version="1.0 [2021.08.06]"

# 1.0 [2021.08.06]

source="Termux Make"

chown 0.2000 "/system/xbin/mkbootimg"
chmod 0755 "/system/xbin/mkbootimg"

chown 0.2000 "/system/xbin/unpackbootimg"
chmod 0755 "/system/xbin/unpackbootimg"

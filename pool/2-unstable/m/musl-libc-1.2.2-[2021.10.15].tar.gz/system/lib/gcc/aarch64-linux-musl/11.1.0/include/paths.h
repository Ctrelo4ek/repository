#ifndef _PATHS_H
#define _PATHS_H

#define	_PATH_DEFPATH "/data/data/com.termux/files/usr/bin:/system/bin:/system/xbin"
#define	_PATH_STDPATH "/data/data/com.termux/files/usr/bin:/system/bin:/system/xbin"

#define	_PATH_BSHELL	"/data/data/com.termux/files/usr/bin/sh"
#define	_PATH_CONSOLE	"/dev/console"
#define	_PATH_DEVNULL	"/dev/null"
#define	_PATH_KLOG	"/proc/kmsg"
#define	_PATH_LASTLOG	"/data/data/com.termux/files/usr/var/log/last-log.txt"
#define	_PATH_MAILDIR	"/data/local/.config/mail"
#define	_PATH_MAN	"/data/data/com.termux/files/usr/share/man"
#define	_PATH_MNTTAB	"/system/etc/fstab"
#define	_PATH_MOUNTED	" /system/etc/mtab"
#define	_PATH_NOLOGIN	"/system/etc/nologin"
#define	_PATH_SENDMAIL	"/system/xbin/sendmail"
#define	_PATH_SHADOW	"/system/etc/shadow"
#define	_PATH_SHELLS	"/system/etc/shells"
#define	_PATH_TTY	"/dev/tty"
#define _PATH_UTMP	"/dev/null/utmp"
#define	_PATH_VI	"/system/xbin/vi"
#define _PATH_WTMP	"/dev/null/wtmp"

#define	_PATH_DEV	"/dev/"
#define	_PATH_TMP	"/data/data/com.termux/files/usr/tmp/"
#define	_PATH_VARDB	"/data/data/com.termux/files/usr/var/lib/musl/"
#define	_PATH_VARRUN	"/data/data/com.termux/files/usr/var/run/"
#define	_PATH_VARTMP	"/data/data/com.termux/files/usr/tmp/"

#endif

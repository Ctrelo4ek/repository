#!/system/bin/sh

# SHELL SCRIPT (SH)

name="m4"
version="1.4.19 [2021.08.07]"

# 1.4.19 [2021.08.07]

source="Termux Make"
source_2="https://github.com/Zackptg5/GNU-Utils-Android"

chown 0.0 "/system/aarch64-linux-android"
chmod 0755 "/system/aarch64-linux-android"

chown 0.2000 "/system/aarch64-linux-android/bin"
chmod 0755 "/system/aarch64-linux-android/bin"

chown 0.0 "/system/lib/charset.alias"
chmod 0644 "/system/lib/charset.alias"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/charset.alias"

chown 0.2000 "/system/xbin/m4"
chmod 0755 "/system/xbin/m4"

ln -s "../../xbin/m4" "/system/aarch64-linux-android/bin/m4"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="android-image-tools"
version="30.0.2 [NDK 22 D] [2021.08.30]"

# 30.0.2 [NDK 22 D] [2021.08.30]

source="Termux Make"

chown 0.2000 "/system/xbin/append2simg"
chmod 0755 "/system/xbin/append2simg"

chown 0.2000 "/system/xbin/img2simg"
chmod 0755 "/system/xbin/img2simg"

chown 0.2000 "/system/xbin/sefcontext_decompile"
chmod 0755 "/system/xbin/sefcontext_decompile"

chown 0.2000 "/system/xbin/simg2img"
chmod 0755 "/system/xbin/simg2img"

chown 0.2000 "/system/xbin/simg2simg"
chmod 0755 "/system/xbin/simg2simg"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libzip"
version="1.8.0 [2021.10.04]"

# 1.8.0 [2021.07.23]

source="Termux"

chown 0.2000 "/system/lib/libzip.so"
chmod 0755 "/system/lib/libzip.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libzip.so"

# 1.8.0 [2021.10.04]

source_2="Termux Make"

chown 0.2000 "/system/lib64/libzip.so"
chmod 0755 "/system/lib64/libzip.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libzip.so"

chown 0.2000 "/system/xbin/zipcmp"
chmod 0755 "/system/xbin/zipcmp"

chown 0.2000 "/system/xbin/zipmerge"
chmod 0755 "/system/xbin/zipmerge"

chown 0.2000 "/system/xbin/ziptool"
chmod 0755 "/system/xbin/ziptool"

chown 0.2000 "/system/xbin/ziptool_regress"
chmod 0755 "/system/xbin/ziptool_regress"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libdeflate"
version="1.7 [2021.01.07]"

# 1.7 [2021.01.07]

source="Termux Make"

chown 0.0 "/system/lib64/libdeflate.so"
chmod 0644 "/system/lib64/libdeflate.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libdeflate.so"

chown 0.2000 "/system/xbin/libdeflate-benchmark"
chmod 0755 "/system/xbin/libdeflate-benchmark"

chown 0.2000 "/system/xbin/libdeflate-checksum"
chmod 0755 "/system/xbin/libdeflate-checksum"

chown 0.2000 "/system/xbin/libdeflate-gzip"
chmod 0755 "/system/xbin/libdeflate-gzip"

ln -s "libdeflate-gzip" "/system/xbin/libdeflate-gunzip"

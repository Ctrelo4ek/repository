#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libconfig"
version="1.7.3 [2021.08.13]"

# 1.7.3 [2021.08.13]

source="Termux"

chown 0.0 "/system/lib/libconfig.so"
chmod 0644 "/system/lib/libconfig.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libconfig.so"

chown 0.0 "/system/lib/libconfig++.so"
chmod 0644 "/system/lib/libconfig++.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libconfig++.so"

chown 0.0 "/system/lib64/libconfig.so"
chmod 0644 "/system/lib64/libconfig.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libconfig.so"

chown 0.0 "/system/lib64/libconfig++.so"
chmod 0644 "/system/lib64/libconfig++.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libconfig++.so"

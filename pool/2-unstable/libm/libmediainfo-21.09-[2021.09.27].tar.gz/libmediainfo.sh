#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libmediainfo"
version="21.09 [2021.09.27]"

# 21.09 [2021.10.13]

source="Termux"

chown 0.0 "/system/lib/libmediainfo.so"
chmod 0644 "/system/lib/libmediainfo.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libmediainfo.so"

# 21.09 [2021.09.27]

source_2="Termux Make"

chown 0.0 "/system/lib64/libmediainfo.so"
chmod 0644 "/system/lib64/libmediainfo.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libmediainfo.so"

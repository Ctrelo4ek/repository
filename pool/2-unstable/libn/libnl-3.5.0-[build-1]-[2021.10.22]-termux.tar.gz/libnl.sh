#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libnl"
version="3.5.0 [Build 1] [2021.10.22]"

# 11.0

source="Android" 

chown 0.0 "/system/lib/libnl.so"
chmod 0644 "/system/lib/libnl.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libnl.so"

chown 0.0 "/system/lib64/libnl.so"
chmod 0644 "/system/lib64/libnl.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libnl.so"

# 3.5.0 [Build 1] [2021.10.22]

source_2="Termux" 

chown -R 0.0 "/system/etc/libnl"
chmod -R 0644 "/system/etc/libnl"

find "/system/etc/libnl" \( -type d -exec chmod 755 {} + \) -o \( -type f -exec chmod 644 {} + \)

ln -s "../../etc/libnl" "/system/usr/share/libnl"

chown 0.0 "/system/lib/libnl-3.so"
chmod 0644 "/system/lib/libnl-3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libnl-3.so"

chown 0.0 "/system/lib/libnl-genl-3.so"
chmod 0644 "/system/lib/libnl-genl-3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libnl-genl-3.so"

chown 0.0 "/system/lib/libnl-idiag-3.so"
chmod 0644 "/system/lib/libnl-idiag-3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libnl-idiag-3.so"

chown 0.0 "/system/lib/libnl-nf-3.so"
chmod 0644 "/system/lib/libnl-nf-3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libnl-nf-3.so"

chown 0.0 "/system/lib/libnl-route-3.so"
chmod 0644 "/system/lib/libnl-route-3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libnl-route-3.so"

chown 0.0 "/system/lib/libnl-xfrm-3.so"
chmod 0644 "/system/lib/libnl-xfrm-3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libnl-xfrm-3.so"

chown 0.0 "/system/lib64/libnl-3.so"
chmod 0644 "/system/lib64/libnl-3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libnl-3.so"

chown 0.0 "/system/lib64/libnl-genl-3.so"
chmod 0644 "/system/lib64/libnl-genl-3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libnl-genl-3.so"

chown 0.0 "/system/lib64/libnl-idiag-3.so"
chmod 0644 "/system/lib64/libnl-idiag-3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libnl-idiag-3.so"

chown 0.0 "/system/lib64/libnl-nf-3.so"
chmod 0644 "/system/lib64/libnl-nf-3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libnl-nf-3.so"

chown 0.0 "/system/lib64/libnl-route-3.so"
chmod 0644 "/system/lib64/libnl-route-3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libnl-route-3.so"

chown 0.0 "/system/lib64/libnl-xfrm-3.so"
chmod 0644 "/system/lib64/libnl-xfrm-3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libnl-xfrm-3.so"

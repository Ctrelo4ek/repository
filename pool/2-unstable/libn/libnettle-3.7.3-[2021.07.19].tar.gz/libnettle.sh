#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libnettle"
version="3.7.3 [2021.07.19]"

# 3.7.3 [2021.06.17]

source="Termux"

chown 0.0 "/system/lib/libhogweed.so"
chmod 0644 "/system/lib/libhogweed.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libhogweed.so"

chown 0.0 "/system/lib/libnettle.so"
chmod 0644 "/system/lib/libnettle.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libnettle.so"

# 3.7.3 [2021.07.19]

source_2="Termux Make"

chown 0.0 "/system/lib64/libhogweed.so"
chmod 0644 "/system/lib64/libhogweed.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libhogweed.so"

chown 0.0 "/system/lib64/libnettle.so"
chmod 0644 "/system/lib64/libnettle.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libnettle.so"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libnghttp2"
version="1.46.0 [2021.10.19]"

# 1.46.0 [2021.10.19]

source="Termux"

chown 0.0 "/system/lib/libnghttp2.so"
chmod 0644 "/system/lib/libnghttp2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libnghttp2.so"

chown 0.0 "/system/lib64/libnghttp2.so"
chmod 0644 "/system/lib64/libnghttp2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libnghttp2.so"

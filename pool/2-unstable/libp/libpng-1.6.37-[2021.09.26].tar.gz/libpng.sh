#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libpng"
version="1.6.37 [2021.09.26]"

# 1.6.37 [2019.04.14]

source="Android"

chown 0.0 "/system/lib/libpng.so"
chmod 0644 "/system/lib/libpng.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libpng.so"

chown 0.0 "/system/lib64/libpng.so"
chmod 0644 "/system/lib64/libpng.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpng.so"

# 1.6.37 [2021.09.26]

source="Termux Make"

chown 0.0 "/system/lib/libpng16.so"
chmod 0644 "/system/lib/libpng16.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libpng16.so"

chown 0.0 "/system/lib64/libpng16.so"
chmod 0644 "/system/lib64/libpng16.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpng16.so"

chown 0.2000 "/system/xbin/libpng16-config"
chmod 0755 "/system/xbin/libpng16-config"

ln -s "libpng16-config" /system/xbin/libpng-config"

chown 0.2000 "/system/xbin/png-fix-itxt"
chmod 0755 "/system/xbin/png-fix-itxt"

chown 0.2000 "/system/xbin/pngfix"
chmod 0755 "/system/xbin/pngfix"

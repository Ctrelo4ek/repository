#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libprotobuf-c"
version="1.3.3 [Build 8]"

# 1.3.3 [Build 8]

source="Termux"

chown 0.0 "/system/lib/libprotobuf-c.so"
chmod 0644 "/system/lib/libprotobuf-c.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libprotobuf-c.so"

chown 0.0 "/system/lib64/libprotobuf-c.so"
chmod 0644 "/system/lib64/libprotobuf-c.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libprotobuf-c.so"

chown 0.2000 "/system/xbin/protoc-gen-c"
chmod 0755 "/system/xbin/protoc-gen-c"

ln -s "protoc-gen-c" "/system/xbin/protoc-c"

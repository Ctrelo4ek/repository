#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libpcap"
version="1.10.1 [2021.08.16]"

# 1.10.1 [2021.08.16]

source="Termux Make"

chown 0.0 "/system/lib/libpcap.so"
chmod 0644 "/system/lib/libpcap.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libpcap.so"

source_2="Android"

chown 0.0 "/system/lib64/libpcap.so"
chmod 0644 "/system/lib64/libpcap.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpcap.so"

chown 0.2000 "/system/xbin/pcap-config"
chmod 0755 "/system/xbin/pcap-config"

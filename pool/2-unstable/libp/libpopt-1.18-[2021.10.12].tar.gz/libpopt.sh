#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libpopt"
version="1.18 [2021.10.12]"

# 1.18 [2021.10.12]

source="Termux Make"

chown 0.0 "/system/lib/libpopt.so"
chmod 0644 "/system/lib/libpopt.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libpopt.so"

chown 0.0 "/system/lib64/libpopt.so"
chmod 0644 "/system/lib64/libpopt.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpopt.so"

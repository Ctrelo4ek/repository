Perl patterns
=============

- `comments` matches comments
- `formats` matches format blocks
- `names` matches identifiers
- `strings` matches strings
- `subs` matches subroutine definitions
- `zap_comments` removes comments from matches
- `zap_formats` removes format blocks from matches
- `zap_strings` removes strings from matches

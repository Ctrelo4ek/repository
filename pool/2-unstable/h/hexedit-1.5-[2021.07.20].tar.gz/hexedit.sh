#!/system/bin/sh

# SHELL SCRIPT (SH)

name="hexedit"
version="1.5 [2021.07.20]"

# 1.5 [2021.07.20]

source="Termux Make"

chown 0.2000 "/system/xbin/hexedit"
chmod 0755 "/system/xbin/hexedit"

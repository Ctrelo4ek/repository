#!/system/bin/sh

# SHELL SCRIPT (SH)

name="hfsutils"
version="3.2.6 [2021.08.15]"

# 3.2.6 [2021.08.15]

source="Termux Make"

chown 0.2000 "/system/xbin/hfsutil"
chmod 0755 "/system/xbin/hfsutil"

ln -s "hfsutil" "/system/xbin/hattrib"
ln -s "hfsutil" "/system/xbin/hcd"
ln -s "hfsutil" "/system/xbin/hcopy"
ln -s "hfsutil" "/system/xbin/hdel"
ln -s "hfsutil" "/system/xbin/hdir"
ln -s "hfsutil" "/system/xbin/hformat"
ln -s "hfsutil" "/system/xbin/hls"
ln -s "hfsutil" "/system/xbin/hmkdir"
ln -s "hfsutil" "/system/xbin/hmount"
ln -s "hfsutil" "/system/xbin/hpwd"
ln -s "hfsutil" "/system/xbin/hrename"
ln -s "hfsutil" "/system/xbin/hrmdir"
ln -s "hfsutil" "/system/xbin/humount"
ln -s "hfsutil" "/system/xbin/hvol"

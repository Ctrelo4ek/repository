#!/bin/sh

jsh2colour -threads -1 -extra -external hexen2meso.def -nodefault meso1
jsh2colour -threads -1 -extra -external hexen2meso.def -nodefault meso2
jsh2colour -threads -1 -extra -external hexen2meso.def -nodefault meso3
jsh2colour -threads -1 -extra -external hexen2meso.def -nodefault meso4
jsh2colour -threads -1 -extra -external hexen2meso.def -nodefault meso5
jsh2colour -threads -1 -extra -external hexen2meso.def -nodefault meso6
jsh2colour -threads -1 -extra -external hexen2meso.def -nodefault meso8
jsh2colour -threads -1 -extra -external hexen2meso.def -nodefault meso9

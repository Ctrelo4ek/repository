#!/bin/sh

jsh2colour -threads -1 -extra -external hexen2.def -nodefault demo1
jsh2colour -threads -1 -extra -external hexen2.def -nodefault demo2
jsh2colour -threads -1 -extra -external hexen2.def -nodefault demo3
jsh2colour -threads -1 -extra -external hexen2.def -nodefault village1
jsh2colour -threads -1 -extra -external hexen2.def -nodefault village2
jsh2colour -threads -1 -extra -external hexen2.def -nodefault village3
jsh2colour -threads -1 -extra -external hexen2.def -nodefault village4
jsh2colour -threads -1 -extra -external hexen2.def -nodefault village5

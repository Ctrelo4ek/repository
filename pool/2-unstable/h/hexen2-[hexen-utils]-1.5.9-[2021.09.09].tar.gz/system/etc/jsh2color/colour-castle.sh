#!/bin/sh

jsh2colour -threads -1 -extra -external hexen2castle.def -nodefault castle4
jsh2colour -threads -1 -extra -external hexen2castle.def -nodefault castle5
jsh2colour -threads -1 -extra -external hexen2castle.def -nodefault cath
jsh2colour -threads -1 -extra -external hexen2castle.def -nodefault eidolon
jsh2colour -threads -1 -extra -external hexen2castle.def -nodefault tower
jsh2colour -threads -1 -extra -external hexen2castle.def -nodefault rider1a
jsh2colour -threads -1 -extra -external hexen2egypt.def -nodefault rider2c

#!/bin/sh

jsh2colour -threads -1 -extra -external hexen2egypt.def -nodefault egypt1
jsh2colour -threads -1 -extra -external hexen2egypt.def -nodefault egypt2
jsh2colour -threads -1 -extra -external hexen2egypt.def -nodefault egypt3
jsh2colour -threads -1 -extra -external hexen2egypt.def -nodefault egypt4
jsh2colour -threads -1 -extra -external hexen2egypt.def -nodefault egypt5
jsh2colour -threads -1 -extra -external hexen2egypt.def -nodefault egypt6
jsh2colour -threads -1 -extra -external hexen2egypt.def -nodefault egypt7


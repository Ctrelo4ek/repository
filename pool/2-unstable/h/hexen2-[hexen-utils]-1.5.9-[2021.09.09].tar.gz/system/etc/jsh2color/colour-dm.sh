#!/bin/sh

jsh2colour -threads -1 -extra ravdm1
jsh2colour -threads -1 -extra ravdm2
jsh2colour -threads -1 -extra ravdm3
jsh2colour -threads -1 -extra ravdm4
jsh2colour -threads -1 -extra ravdm5

#!/bin/sh

jsh2colour -threads -1 -extra -external hexen2romeric.def -nodefault romeric1
jsh2colour -threads -1 -extra -external hexen2romeric.def -nodefault romeric2
jsh2colour -threads -1 -extra -external hexen2romeric.def -nodefault romeric3
jsh2colour -threads -1 -extra -external hexen2romeric.def -nodefault romeric4
jsh2colour -threads -1 -extra -external hexen2romeric.def -nodefault romeric5
jsh2colour -threads -1 -extra -external hexen2romeric.def -nodefault romeric6
jsh2colour -threads -1 -extra -external hexen2romeric.def -nodefault romeric7

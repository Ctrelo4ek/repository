#!/system/bin/sh

# SHELL SCRIPT (SH)

name="locale-charset"
version="1.1 [2021.09.11]"

# 1.1 [2021.09.11]

source="Termux Make"

chown 0.2000 "/system/xbin/current-locale"
chmod 0755 "/system/xbin/current-locale"

chown 0.2000 "/system/xbin/test-localcharset"
chmod 0755 "/system/xbin/test-localcharset"

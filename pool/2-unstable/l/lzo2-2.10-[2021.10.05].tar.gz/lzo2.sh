#!/system/bin/sh

# SHELL SCRIPT (SH)

name="lzo2"
version="2.10 [2021.07.11]"

# 2.10 [2021.07.11]

source="Termux Make"

chown -hR 0.0 "/system/etc/pkgconfig"
chmod -R 0644 "/system/etc/pkgconfig"

find "/system/etc/pkgconfig" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/pkgconfig" "/system/usr/share/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib64/pkgconfig"

chown 0.0 "/system/lib/liblzo2.la"
chmod 0644 "/system/lib/liblzo2.la"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/liblzo2.la"

chown 0.0 "/system/lib/liblzo2.so"
chmod 0644 "/system/lib/liblzo2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/liblzo2.so"

chown 0.0 "/system/lib64/liblzo2.so"
chmod 0644 "/system/lib64/liblzo2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/liblzo2.so"

chown 0.2000 "/system/xbin/lzodict"
chmod 0755 "/system/xbin/lzodict"

chown 0.2000 "/system/xbin/lzooverlap"
chmod 0755 "/system/xbin/lzooverlap"

chown 0.2000 "/system/xbin/lzopack"
chmod 0755 "/system/xbin/lzopack"

chown 0.2000 "/system/xbin/lzotest"
chmod 0755 "/system/xbin/lzotest"

chown 0.2000 "/system/xbin/zlocomp"
chmod 0755 "/system/xbin/zlocomp"

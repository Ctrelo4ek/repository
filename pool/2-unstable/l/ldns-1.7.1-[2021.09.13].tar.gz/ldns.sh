#!/system/bin/sh

# SHELL SCRIPT (SH)

name="ldns"
version="1.7.1 [2020.10.09]"

# 1.7.1 [2020.10.09]

source="Termux"

chown 0.0 "/system/lib/libldns.so"
chmod 0644 "/system/lib/libldns.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libldns.so"

chown 0.0 "/system/lib64/libldns.so"
chmod 0644 "/system/lib64/libldns.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libldns.so"

chown 0.2000 "/system/xbin/drill"
chmod 0755 "/system/xbin/drill"

chown 0.2000 "/system/xbin/ldns-config"
chmod 0755 "/system/xbin/ldns-config"

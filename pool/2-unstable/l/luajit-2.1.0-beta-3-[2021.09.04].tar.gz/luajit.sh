#!/system/bin/sh

# SHELL SCRIPT (SH)

name="luajit"
version="2.1.0 Beta 3 [2021.09.04]"

# 2.1.0 Beta 3 [2021.09.04]

source="Termux Make"

chown 0.2000 "/system/xbin/luajit"
chmod 0755 "/system/xbin/luajit"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="pam"
version="1.5.1 [2020.11.27]"

# 1.5.1 [2020.11.27]

source="Termux Make"

chown -hR 0.2000 "/system/etc/pam.d"
chmod -R 0755 "/system/etc/pam.d"

find "/system/etc/pam.d" -type d \( -exec chown -h 0.2000 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.2000 {} + -exec chmod 0755 {} + \)

ln -s "../../etc/pam.d" "/system/usr/share/pam.d"

chown -hR 0.0 "/system/etc/security"
chmod -R 0644 "/system/etc/security"

find "/system/etc/security" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/security" "/system/usr/share/security"

chown 0.0 "/system/etc/environment"
chmod 0644 "/system/etc/environment"

chown 0.0 "/system/etc/pam.conf"
chmod 0644 "/system/etc/pam.conf"

chown -hR 0.0 "/system/lib/security"
chmod -R 0644 "/system/lib/security"

find "/system/lib/security" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../lib/security" "/system/lib64/security"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/security"

chown 0.0 "/system/lib64/libpam.so"
chmod 0644 "/system/lib64/libpam.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpam.so"

chown 0.0 "/system/lib64/libpam_misc.so"
chmod 0644 "/system/lib64/libpam_misc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpam_misc.so"

chown 0.0 "/system/lib64/libpamc.so"
chmod 0644 "/system/lib64/libpamc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpamc.so"

chown 0.2000 "/system/xbin/bigcrypt"
chmod 0755 "/system/xbin/bigcrypt"

chown 0.2000 "/system/xbin/blank"
chmod 0755 "/system/xbin/blank"

chown 0.2000 "/system/xbin/check_user"
chmod 0755 "/system/xbin/check_user"

chown 0.2000 "/system/xbin/faillock"
chmod 0755 "/system/xbin/XXX"

chown 0.2000 "/system/xbin/mkhomedir_helper"
chmod 0755 "/system/xbin/mkhomedir_helper"

chown 0.2000 "/system/xbin/padout"
chmod 0755 "/system/xbin/padout"

chown 0.2000 "/system/xbin/pam_conv1"
chmod 0755 "/system/xbin/pam_conv1"

chown 0.2000 "/system/xbin/pam_namespace_helper"
chmod 0755 "/system/xbin/pam_namespace_helper"

chown 0.2000 "/system/xbin/pam_selinux_check"
chmod 0755 "/system/xbin/pam_selinux_check"

chown 0.2000 "/system/xbin/pam_timestamp_check"
chmod 0755 "/system/xbin/pam_timestamp_check"

chown 0.2000 "/system/xbin/pwhistory_helper"
chmod 0755 "/system/xbin/pwhistory_helper"

chown 0.2000 "/system/xbin/unix_chkpwd"
chmod 0755 "/system/xbin/unix_chkpwd"

chown 0.2000 "/system/xbin/unix_update"
chmod 0755 "/system/xbin/unix_update"

chown 0.2000 "/system/xbin/upperLOWER"
chmod 0755 "/system/xbin/upperLOWER"

ln -s "../../../xbin/upperLOWER" "/system/lib/security/pam_filter/upperLOWER"

chown 0.2000 "/system/xbin/vpass"
chmod 0755 "/system/xbin/vpass"

chown 0.2000 "/system/xbin/xsh"
chmod 0755 "/system/xbin/xsh"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libjasper"
version="2.0.33 [2021.09.09]"

# 2.0.33 [2021.09.09]

source="Termux"

chown 0.0 "/system/lib/libjasper.so"
chmod 0644 "/system/lib/libjasper.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libjasper.so"

chown 0.0 "/system/lib64/libjasper.so"
chmod 0644 "/system/lib64/libjasper.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libjasper.so"

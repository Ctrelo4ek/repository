#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libjpeg-turbo"
version="2.1.1 [2021.08.11]"

# 2.0.2

source="Android"

chown 0.0 "/system/lib/libjpeg.so"
chmod 0644 "/system/lib/libjpeg.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libjpeg.so"

chown 0.0 "/system/lib64/libjpeg.so"
chmod 0644 "/system/lib64/libjpeg.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libjpeg.so"

# 2.1.1 [2021.08.11]

source_2="Termux Make"

chown 0.0 "/system/lib/libjpg.so"
chmod 0644 "/system/lib/libjpg.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libjpg.so"

chown 0.0 "/system/lib64/libjpg.so"
chmod 0644 "/system/lib64/libjpg.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libjpg.so"

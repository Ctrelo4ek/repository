#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libffi"
version="3.3.2"

# 3.3.2

source="Termux"

chown 0.0 "/system/aarch64-linux-android"
chmod 0755 "/system/aarch64-linux-android"

chown 0.0 "/system/aarch64-linux-android/lib"
chmod 0644 "/system/aarch64-linux-android/lib"

ln -s "lib" "/system/aarch64-linux-android/lib64"

chcon -hR u:object_r:system_lib_file:s0 "/system/aarch64-linux-android/lib"

chown -hR 0.0 "/system/lib/gcc"
chmod -R 0644 "/system/lib/gcc"

find "/system/lib/gcc" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../lib/gcc" "/system/aarch64-linux-android/lib/gcc"
ln -s "../lib/gcc" "/system/lib64/gcc"

chcon -hR u:object_r:system_file:s0 "/system/lib/gcc"

chown 0.0 "/system/lib/libffi.so"
chmod 0644 "/system/lib/libffi.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libffi.so"

chown 0.0 "/system/lib64/libffi.so"
chmod 0644 "/system/lib64/libffi.so"

ln -s "../../../../lib64/libffi.so" "/system/libexec/gcc/aarch64-linux-android/release/libffi.so"
ln -s "../../lib64/libffi.so" "/system/aarch64-linux-android/lib/libffi.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libffi.so"

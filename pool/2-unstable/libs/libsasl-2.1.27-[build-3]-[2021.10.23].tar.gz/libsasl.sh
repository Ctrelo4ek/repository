#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libsasl"
version="2.1.27 [Build 3] [2021.10.23]"

# 2.1.27 [Build 3] [2021.10.23]

source="Termux"

chown -hR 0.0 "/system/lib/sasl2"
chmod -R 0644 "/system/lib/sasl2"

find "/system/lib/sasl2" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../lib/sasl2" "/system/lib64/sasl2"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/sasl2"

chown 0.0 "/system/lib/libsasl2.so"
chmod 0644 "/system/lib/libsasl2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libsasl2.so"

chown 0.0 "/system/lib64/libsasl2.so"
chmod 0644 "/system/lib64/libsasl2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libsasl2.so"

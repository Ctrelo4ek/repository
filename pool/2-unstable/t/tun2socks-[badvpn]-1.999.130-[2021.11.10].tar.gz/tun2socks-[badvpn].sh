#!/system/bin/sh

# SHELL SCRIPT (SH)

name="tun2socks [badvpn]"
version="1.999.130"

# 1.999.130

chown 0.2000 "/system/xbin/tun2socks"
chmod 0755 "/system/xbin/tun2socks"

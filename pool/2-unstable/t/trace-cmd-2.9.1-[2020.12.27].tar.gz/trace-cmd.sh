#!/system/bin/sh

# SHELL SCRIPT (SH)

name="trace-cmd"
version="2.9.1 [2020.12.27]"

# 2.9.1 [2020.12.27]

source="Termux Make"

chown 0.2000 "/system/bin/trace-cmd"
chmod 0755 "/system/bin/trace-cmd"

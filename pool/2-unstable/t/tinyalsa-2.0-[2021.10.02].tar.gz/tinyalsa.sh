#!/system/bin/sh

# SHELL SCRIPT (SH)

name="tinyalsa"
version="11.0"

# 11.0

source="Android"

chown 0.2000 "/system/bin/tinymix"
chmod 0755 "/system/bin/tinymix"

chown 0.0 "/system/lib/libtinyalsa.so"
chmod 0644 "/system/lib/libtinyalsa.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libtinyalsa.so"

chown 0.0 "/system/lib64/libtinyalsa.so"
chmod 0644 "/system/lib64/libtinyalsa.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libtinyalsa.so"

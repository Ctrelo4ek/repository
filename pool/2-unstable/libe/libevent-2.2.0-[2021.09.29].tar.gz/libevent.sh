#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libevent"
version="2.2.0 [2021.09.29]"

# 2.1.12

source="Termux"

chown 0.0 "/system/lib/libevent.so"
chmod 0644 "/system/lib/libevent.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libevent.so"

chown 0.0 "/system/lib/libevent_core.so"
chmod 0644 "/system/lib/libevent_core.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libevent_core.so"

chown 0.0 "/system/lib/libevent_extra.so"
chmod 0644 "/system/lib/libevent_extra.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libevent_extra.so"

chown 0.0 "/system/lib/libevent_pthreads.so"
chmod 0644 "/system/lib/libevent_pthreads.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libevent_pthreads.so"

# 2.2.0 [2021.09.29]

source_2="Termux Make"

chown 0.0 "/system/lib64/libevent.so"
chmod 0644 "/system/lib64/libevent.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libevent.so"

chown 0.0 "/system/lib64/libevent_core.so"
chmod 0644 "/system/lib64/libevent_core.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libevent_core.so"

chown 0.0 "/system/lib64/libevent_extra.so"
chmod 0644 "/system/lib64/libevent_extra.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libevent_extra.so"

chown 0.0 "/system/lib64/libevent_pthreads.so"
chmod 0644 "/system/lib64/libevent_pthreads.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libevent_pthreads.so"

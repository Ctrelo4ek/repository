#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libexpat"
version="2.4.1 [2021.08.15]"

# 2.4.1 [Build 1]

source="Termux"

chown 0.0 "/system/lib/libexpat.so"
chmod 0644 "/system/lib/libexpat.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libexpat.so"


# 2.4.1 [2021.08.15]

source_2="Termux Make"

chown 0.0 "/system/lib64/libexpat.so"
chmod 0644 "/system/lib64/libexpat.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libexpat.so"

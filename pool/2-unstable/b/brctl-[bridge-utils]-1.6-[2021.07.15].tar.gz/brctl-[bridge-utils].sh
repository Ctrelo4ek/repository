#!/system/bin/sh

# SHELL SCRIPT (SH)

name="brctl [bridge-utils]"
version="1.6 [2021.07.15]"

# 1.6 [2021.07.15]

source="Termux Make"

chown 0.2000 "/system/xbin/brctl"
chmod 0755 "/system/xbin/brctl"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="binutils-lib"
version="2.37.50 [2021.09.14]"

# 2.37.50 [2021.09.14]

source="Termux Make"
source_2="https://github.com/henriknelson/binutils-magisk-module"

chown 0.0 "/system/aarch64-linux-android"
chmod 0755 "/system/aarch64-linux-android"

chown 0.2000 "/system/aarch64-linux-android/bin"
chmod 0755 "/system/aarch64-linux-android/bin"

chown 0.0 "/system/aarch64-linux-android/lib"
chmod 0644 "/system/aarch64-linux-android/lib"

ln -s "lib" "/system/aarch64-linux-android/lib64"

chcon -hR u:object_r:system_lib_file:s0 "/system/aarch64-linux-android/lib"

chown -hR 0.0 "/system/lib/gcc"
chmod -R 0644 "/system/lib/gcc"

find "/system/lib/gcc" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../lib/gcc" "/system/aarch64-linux-android/lib/gcc"
ln -s "../lib/gcc" "/system/lib64/gcc"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/gcc"

chown 0.0 "/system/lib/libbfd.so"
chmod 0644 "/system/lib/libbfd.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libbfd.so"

chown 0.0 "/system/lib/libctf.so"
chmod 0644 "/system/lib/libctf.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libctf.so"

chown 0.0 "/system/lib/libctf-nobfd.so"
chmod 0644 "/system/lib/libctf-nobfd.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libctf-nobfd.so"

chown 0.0 "/system/lib/libopcodes.so"
chmod 0644 "/system/lib/libopcodes.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libopcodes.so"

chown 0.0 "/system/lib64/libbfd.so"
chmod 0644 "/system/lib64/libbfd.so"

ln -s "../../../../lib64/libbfd.so" "/system/lib/gcc/aarch64-linux-android/release/libbfd.so"
ln -s "../../lib64/libbfd.so" "/system/aarch64-linux-android/lib/libbfd.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libbfd.so"

chown 0.0 "/system/lib64/libctf.so"
chmod 0644 "/system/lib64/libctf.so"

ln -s "../../../../lib64/libctf.so" "/system/lib/gcc/aarch64-linux-android/release/libctf.so"
ln -s "../../lib64/libctf.so" "/system/aarch64-linux-android/lib/libctf.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libctf.so"

chown 0.0 "/system/lib64/libctf-nobfd.so"
chmod 0644 "/system/lib64/libctf-nobfd.so"

ln -s "../../../../lib64/libctf-nobfd.so" "/system/lib/gcc/aarch64-linux-android/release/libctf-nobfd.so"
ln -s "../../lib64/libctf-nobfd.so" "/system/aarch64-linux-android/lib/libctf-nobfd.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libctf-nobfd.so"

chown 0.0 "/system/lib64/libldtestplug.so"
chmod 0644 "/system/lib64/libldtestplug.so"

ln -s "../../../../lib64/libldtestplug.so" "/system/lib/gcc/aarch64-linux-android/release/libldtestplug.so"
ln -s "../../lib64/libldtestplug.so" "/system/aarch64-linux-android/lib/libldtestplug.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libldtestplug.so"

chown 0.0 "/system/lib64/libopcodes.so"
chmod 0644 "/system/lib64/libopcodes.so"

ln -s "../../../../lib64/libopcodes.so" "/system/lib/gcc/aarch64-linux-android/release/libopcodes.so"
ln -s "../../lib64/libopcodes.so" "/system/aarch64-linux-android/lib/libopcodes.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libopcodes.so"

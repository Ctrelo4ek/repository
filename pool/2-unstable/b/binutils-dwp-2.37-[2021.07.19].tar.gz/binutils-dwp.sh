#!/system/bin/sh

# SHELL SCRIPT (SH)

name="binutils-dwp"
version="2.37 [2021.07.19]"

# 2.37 [2021.07.19]

source="Termux Make"
source_2="https://github.com/henriknelson/binutils-magisk-module"

chown 0.0 "/system/aarch64-linux-android"
chmod 0755 "/system/aarch64-linux-android"

chown 0.2000 "/system/aarch64-linux-android/bin"
chmod 0755 "/system/aarch64-linux-android/bin"

chown 0.2000 "/system/xbin/dwp"
chmod 0755 "/system/xbin/dwp"

ln -s "../../xbin/dwp" "/system/aarch64-linux-android/bin/dwp"
ln -s "dwp" "/system/xbin/aarch64-linux-android-dwp"

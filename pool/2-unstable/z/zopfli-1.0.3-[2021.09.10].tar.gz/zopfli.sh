#!/system/bin/sh

# SHELL SCRIPT (SH)

name="zopfli"
version="1.0.3 [2021.09.10]"

# 1.0.3 [2021.09.10]

source="Termux Make"

chown 0.0 "/system/lib/libzopfli.so"
chmod 0644 "/system/lib/libzopfli.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libzopfli.so"

chown 0.0 "/system/lib/zopflipng.so"
chmod 0644 "/system/lib/zopflipng.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/zopflipng.so"

chown 0.0 "/system/lib64/libzopfli.so"
chmod 0644 "/system/lib64/libzopfli.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libzopfli.so"

chown 0.0 "/system/lib64/zopflipng.so"
chmod 0644 "/system/lib64/zopflipng.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/zopflipng.so"

chown 0.2000 "/system/xbin/zopfli"
chmod 0755 "/system/xbin/zopfli"

chown 0.2000 "/system/xbin/zopflipng"
chmod 0755 "/system/xbin/zopflipng"

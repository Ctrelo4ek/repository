#!/system/bin/sh

# SHELL SCRIPT (SH)

name="ncurses"
version="6.2 [ABI 6] [2020.07.25]"

# 11.0

source="Android"

chown 0.0 "/system/lib64/libncurses.so"
chmod 0644 "/system/lib64/libncurses.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libncurses.so"

# 6.2 [ABI 6] [2020.07.25]

chown -hR 0.0 "/system/etc/tabset"
chmod -R 0644 "/system/etc/tabset"

find "/system/etc/tabset" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/tabset" "/system/usr/share/tabset"

chown -hR 0.0 "/system/etc/terminfo"
chmod -R 0644 "/system/etc/terminfo"

find "/system/etc/terminfo" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/terminfo" "/system/aarch64-linux-android/lib/terminfo"
ln -s "../../etc/terminfo" "/system/usr/share/terminfo"
ln -s "../etc/terminfo" "/system/lib/terminfo"
ln -s "../etc/terminfo" "/system/lib64/terminfo"

chown 0.0 "/system/lib64/libformw.so"
chmod 0644 "/system/lib64/libformw.so"

ln -s "libformw.so" "/system/lib64/libform.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libformw.so"

chown 0.0 "/system/lib64/libmenuw.so"
chmod 0644 "/system/lib64/libmenuw.so"

ln -s "libmenuw.so" "/system/lib64/libmenu.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libmenuw.so"

chown 0.0 "/system/lib64/libncursesw.so"
chmod 0644 "/system/lib64/libncursesw.so"

ln -s "libncursesw.so" "/system/lib64/libcurses.so"
# ln -s "libncursesw.so" "/system/lib64/libncurses.so"
ln -s "libncursesw.so" "/system/lib64/libtermcap.so"
ln -s "libncursesw.so" "/system/lib64/libtic.so"
ln -s "libncursesw.so" "/system/lib64/libtinfo.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libncursesw.so"

chown 0.0 "/system/lib64/libpanelw.so"
chmod 0644 "/system/lib64/libpanelw.so"

ln -s "libpanelw.so" "/system/lib64/libpanel.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpanelw.so"

chown 0.2000 "/system/xbin/clear"
chmod 0755 "/system/xbin/clear"

chown 0.2000 "/system/xbin/infocmp"
chmod 0755 "/system/xbin/infocmp"

chown 0.2000 "/system/xbin/ncursesw6-config"
chmod 0755 "/system/xbin/ncursesw6-config"

chown 0.2000 "/system/xbin/tabs"
chmod 0755 "/system/xbin/tabs"

chown 0.2000 "/system/xbin/tic"
chmod 0755 "/system/xbin/tic"

ln -s "tic" "/system/xbin/captoinfo"
ln -s "tic" "/system/xbin/infotocap"

chown 0.2000 "/system/xbin/toe"
chmod 0755 "/system/xbin/toe"

chown 0.2000 "/system/xbin/tput"
chmod 0755 "/system/xbin/tput"

chown 0.2000 "/system/xbin/tset"
chmod 0755 "/system/xbin/tset"

ln -s "tset" "/system/xbin/reset"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="ntfs-3g"
version="2021.8.22 [2021.08.31]"

# 2017.3.23 [Fuse 27]

source="Android"

chown 0.2000 "/system/bin/fsck.ntfs"
chmod 0755 "/system/bin/fsck.ntfs"

ln -s "fsck.ntfs" "/system/bin/ntfsfix"

chcon -hR u:object_r:fsck_exec:s0 "/system/bin/fsck.ntfs"

chown 0.2000 "/system/bin/mkfs.ntfs"
chmod 0755 "/system/bin/mkfs.ntfs"

ln -s "mkfs.ntfs" "/system/bin/mkntfs"

chcon -hR u:object_r:fsck_exec:s0 "/system/bin/mkfs.ntfs"

chown 0.2000 "/system/bin/mount.ntfs"
chmod 0755 "/system/bin/mount.ntfs"

ln -s "mount.ntfs" "/system/bin/ntfs-3g"

chcon -hR u:object_r:fsck_exec:s0 "/system/bin/mount.ntfs"

chown 0.0 "/system/lib/libappfuse.so"
chmod 0644 "/system/lib/libappfuse.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libappfuse.so"

chown 0.0 "/system/lib/libntfs-3g.so"
chmod 0644 "/system/lib/libntfs-3g.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libntfs-3g.so"

chown 0.0 "/system/lib64/libappfuse.so"
chmod 0644 "/system/lib64/libappfuse.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libappfuse.so"

chown 0.0 "/system/lib64/libfuse-lite.so"
chmod 0644 "/system/lib64/libfuse-lite.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libfuse-lite.so"

# 2021.8.22 [2021.08.31]

source_2="Termux Make"

chown -hR 0.2000 "/system/lib/ntfs-3g"
chmod -R 0755 "/system/lib/ntfs-3g"

find "/system/lib/ntfs-3g" -type d \( -exec chown -h 0.2000 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.2000 {} + -exec chmod 0755 {} + \)

ln -s "../lib/ntfs-3g" "/system/lib64/ntfs-3g"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/ntfs-3g"

chown 0.0 "/system/lib64/libntfs-3g.so"
chmod 0644 "/system/lib64/libntfs-3g.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libntfs-3g.so"

chown 0.2000 "/system/xbin/lowntfs-3g"
chmod 0755 "/system/xbin/lowntfs-3g"

ln -s "mkntfs" "/system/xbin/mount.lowntfs"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/lowntfs-3g"

chown 0.2000 "/system/xbin/mkntfs"
chmod 0755 "/system/xbin/mkntfs"

ln -s "mkntfs" "/system/xbin/mkfs.ntfs"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/mkntfs"

chown 0.2000 "/system/xbin/ntfs-3g"
chmod 0755 "/system/xbin/ntfs-3g"

ln -s "ntfs-3g" "/system/xbin/mount.ntfs"
ln -s "ntfs-3g" "/system/xbin/mount.ntfs-3g"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfs-3g"

chown 0.2000 "/system/xbin/ntfs-3g.probe"
chmod 0755 "/system/xbin/ntfs-3g.probe"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfs-3g.probe"

chown 0.2000 "/system/xbin/ntfscat"
chmod 0755 "/system/xbin/ntfscat"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfscat"

chown 0.2000 "/system/xbin/ntfsck"
chmod 0755 "/system/xbin/ntfsck"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsck"

chown 0.2000 "/system/xbin/ntfsclone"
chmod 0755 "/system/xbin/ntfsclone"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsclone"

chown 0.2000 "/system/xbin/ntfscluster"
chmod 0755 "/system/xbin/ntfscluster"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfscluster"

chown 0.2000 "/system/xbin/ntfscmp"
chmod 0755 "/system/xbin/ntfscmp"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfscmp"

chown 0.2000 "/system/xbin/ntfscp"
chmod 0755 "/system/xbin/ntfscp"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfscp"

chown 0.2000 "/system/xbin/ntfsdebug"
chmod 0755 "/system/xbin/ntfsdebug"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsdebug"

chown 0.2000 "/system/xbin/ntfsdecrypt"
chmod 0755 "/system/xbin/ntfsdecrypt"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsdecrypt"

chown 0.2000 "/system/xbin/ntfsdump_logfile"
chmod 0755 "/system/xbin/ntfsdump_logfile"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsdump_logfile"

chown 0.2000 "/system/xbin/ntfsfallocate"
chmod 0755 "/system/xbin/ntfsfallocate"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsfallocate"

chown 0.2000 "/system/xbin/ntfsfix"
chmod 0755 "/system/xbin/ntfsfix"

ln -s "ntfsfix" "/system/xbin/fsck.ntfs"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsfix"

chown 0.2000 "/system/xbin/ntfsinfo"
chmod 0755 "/system/xbin/ntfsinfo"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsinfo"

chown 0.2000 "/system/xbin/ntfslabel"
chmod 0755 "/system/xbin/ntfslabel"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfslabel"

chown 0.2000 "/system/xbin/ntfsls"
chmod 0755 "/system/xbin/ntfsls"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsls"

chown 0.2000 "/system/xbin/ntfsmftalloc"
chmod 0755 "/system/xbin/ntfsmftalloc"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsmftalloc"

chown 0.2000 "/system/xbin/ntfsmove"
chmod 0755 "/system/xbin/ntfsmove"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsmove"

chown 0.2000 "/system/xbin/ntfsrecover"
chmod 0755 "/system/xbin/ntfsrecover"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsrecover"

chown 0.2000 "/system/xbin/ntfsresize"
chmod 0755 "/system/xbin/ntfsresize"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsresize"

chown 0.2000 "/system/xbin/ntfssecaudit"
chmod 0755 "/system/xbin/ntfssecaudit"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfssecaudit"

chown 0.2000 "/system/xbin/ntfstruncate"
chmod 0755 "/system/xbin/ntfstruncate"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfstruncate"

chown 0.2000 "/system/xbin/ntfsundelete"
chmod 0755 "/system/xbin/ntfsundelete"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsundelete"

chown 0.2000 "/system/xbin/ntfsusermap"
chmod 0755 "/system/xbin/ntfsusermap"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfsusermap"

chown 0.2000 "/system/xbin/ntfswipe"
chmod 0755 "/system/xbin/ntfswipe"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/ntfswipe"

#!/bin/sh
#
# nsd-control-setup.sh - set up SSL certificates for nsd-control
#
# Copyright (c) 2011, NLnet Labs. All rights reserved.
#
# This software is open source.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# Redistributions of source code must retain the above copyright notice,
# this list of conditions and the following disclaimer.
#
# Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# Neither the name of the NLNET LABS nor the names of its contributors may
# be used to endorse or promote products derived from this software without
# specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
# HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# settings:

# directory for files
DESTDIR=/data/data/com.termux/files/usr/etc/nsd

# issuer and subject name for certificates
SERVERNAME=nsd
CLIENTNAME=nsd-control

# validity period for certificates
DAYS=3650

# size of keys in bits
BITS=3072

# hash algorithm
HASH=sha256

# base name for nsd server keys
SVR_BASE=nsd_server

# base name for nsd-control keys
CTL_BASE=nsd_control

# flag to recreate generated certificates
RECREATE=0

# we want -rw-r--- access (say you run this as root: grp=yes (server), all=no).
umask 0026

# end of options

set -eu

cleanup() {
    echo "removing artifacts"

    rm -rf \
       server.cnf \
       client.cnf \
       "${SVR_BASE}_trust.pem" \
       "${CTL_BASE}_trust.pem" \
       "${SVR_BASE}_trust.srl"
}

fatal() {
    printf "fatal error: $*\n" >/dev/stderr
    exit 1
}

usage() {
    cat <<EOF
usage: $0 OPTIONS

OPTIONS

-d <dir>  used directory to store keys and certificates (default: $DESTDIR)
-h        show help notice
-r        recreate certificates
EOF
}

OPTIND=1
while getopts 'd:hr' arg; do
    case "$arg" in
      d) DESTDIR="$OPTARG" ;;
      h) usage; exit 0 ;;
      r) RECREATE=1 ;;
      ?) fatal "'$arg' unknown option" ;;
    esac
done
shift $((OPTIND - 1))


echo "setup in directory $DESTDIR"
cd "$DESTDIR"

trap cleanup INT

# ===
# Generate server certificate
# ===

# generate private key; do no recreate it if they already exist.
if [ ! -f "$SVR_BASE.key" ]; then
    openssl genrsa -out "$SVR_BASE.key" "$BITS"
fi

cat >server.cnf <<EOF
default_bits=$BITS
default_md=$HASH
prompt=no
distinguished_name=req_distinguished_name

[req_distinguished_name]
commonName=$SERVERNAME
EOF

[ -f server.cnf ] || fatal "cannot create openssl configuration"

if [ ! -f "$SVR_BASE.pem" -o $RECREATE -eq 1 ]; then
    openssl req \
            -new -x509 \
            -key "$SVR_BASE.key" \
            -config server.cnf  \
            -days "$DAYS" \
            -out "$SVR_BASE.pem"

    [ ! -f "SVR_BASE.pem" ] || fatal "cannot create server certificate"
fi

# ===
# Generate client certificate
# ===

# generate private key; do no recreate it if they already exist.
if [ ! -f "$CTL_BASE.key" ]; then
    openssl genrsa -out "$CTL_BASE.key" "$BITS"
fi

cat >client.cnf <<EOF
[req]
default_bits=$BITS
default_md=$HASH
prompt=no
distinguished_name=req_distinguished_name

[req_distinguished_name]
commonName=$CLIENTNAME
EOF

[ -f client.cnf ] || fatal "cannot create openssl configuration"

if [ ! -f "$CTL_BASE.pem" -o $RECREATE -eq 1 ]; then
    openssl x509 \
        -addtrust serverAuth \
        -in "$SVR_BASE.pem" \
        -out "${SVR_BASE}_trust.pem"

    openssl req \
            -new \
            -config client.cnf \
            -key "$CTL_BASE.key" \
        | openssl x509 \
                  -req \
                  -days "$DAYS" \
                  -CA "${SVR_BASE}_trust.pem" \
                  -CAkey "$SVR_BASE.key" \
                  -CAcreateserial \
                  -$HASH \
                  -out "$CTL_BASE.pem"

    [ ! -f "CTL_BASE.pem" ] || fatal "cannot create signed client certificate"
fi

# remove unused permissions
chmod o-rw \
      "$SVR_BASE.pem" \
      "$SVR_BASE.key" \
      "$CTL_BASE.pem" \
      "$CTL_BASE.key"

cleanup

echo "Setup success. Certificates created. Enable in nsd.conf file to use"


# create trusted usage pem
# openssl x509 -in $CTL_BASE.pem -addtrust clientAuth -out $CTL_BASE"_trust.pem"

# see details with openssl x509 -noout -text < $SVR_BASE.pem
# echo "create $CTL_BASE""_browser.pfx (web client certificate)"
# echo "create webbrowser PKCS#12 .PFX certificate file. In Firefox import in:"
# echo "preferences - advanced - encryption - view certificates - your certs"
# echo "empty password is used, simply click OK on the password dialog box."
# openssl pkcs12 -export -in $CTL_BASE"_trust.pem" -inkey $CTL_BASE.key -name "nsd remote control client cert" -out $CTL_BASE"_browser.pfx" -password "pass:" || error "could not create browser certificate"

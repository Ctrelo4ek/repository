#!/system/bin/sh

# SHELL SCRIPT (SH)

name="nnn"
version="4.3 [2021.09.30]"

# 4.3 [2021.09.30]

source="Termux Make"

chown 0.2000 "/system/xbin/nnn"
chmod 0755 "/system/xbin/nnn"

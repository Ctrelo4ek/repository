#!/system/bin/sh

# SHELL SCRIPT (SH)

name="nettle"
version="3.7.3 [2021.08.06]"

# 3.7.3 [2021.08.06]

source="Termux Make"

chown 0.2000 "/system/xbin/nettle-hash"
chmod 0755 "/system/xbin/nettle-hash"

chown 0.2000 "/system/xbin/nettle-lfib-stream"
chmod 0755 "/system/xbin/nettle-lfib-stream"

chown 0.2000 "/system/xbin/nettle-pbkdf2"
chmod 0755 "/system/xbin/nettle-pbkdf2"

chown 0.2000 "/system/xbin/pkcs1-conv"
chmod 0755 "/system/xbin/pkcs1-conv"

chown 0.2000 "/system/xbin/sexp-conv"
chmod 0755 "/system/xbin/sexp-conv"

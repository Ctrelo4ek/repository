#!/system/bin/sh

# SHELL SCRIPT (SH)

name="exfat-linux"
version="3017.7.17.3"

# 3017.7.17.3

source="Termux Make"

chown 0.2000 "/system/bin/dumpexfat"
chmod 0755 "/system/bin/dumpexfat"

chown 0.2000 "/system/bin/exfatfsck"
chmod 0755 "/system/bin/exfatfsck"

ln -s "exfatfsck" "/system/bin/exfatck"
ln -s "exfatfsck" "/system/bin/fsck.exfat"

chcon -hR u:object_r:fsck_exec:s0 "/system/bin/exfatfsck"

chown 0.2000 "/system/bin/exfatlabel"
chmod 0755 "/system/bin/exfatlabel"

chown 0.2000 "/system/bin/mkexfatfs"
chmod 0755 "/system/bin/mkexfatfs"

ln -s "mkexfatfs" "/system/bin/mkexfat"
ln -s "mkexfatfs" "/system/bin/mkfs.exfat"

chcon -hR u:object_r:mkfs_exec:s0 "/system/bin/mkexfatfs"

chown 0.2000 "/system/bin/mount.exfat-fuse"
chmod 0755 "/system/bin/mount.exfat-fuse"

ln -s "mount.exfat-fuse" "/system/bin/mount.exfat"

chown 0.0 "/system/lib64/libexfat.so"
chmod 0644 "/system/lib64/libexfat.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libexfat.so"

# 3017.7.17.3

chown 0.2000 "/system/xbin/exfatck"
chmod 0755 "/system/xbin/exfatck"

ln -s "exfatck" "/system/xbin/exfatfsck"
ln -s "exfatck" "/system/xbin/fsck.exfat"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/exfatck"

chown 0.2000 "/system/xbin/exfatdebug"
chmod 0755 "/system/xbin/exfatdebug"

chown 0.2000 "/system/xbin/exfatinfo"
chmod 0755 "/system/xbin/exfatinfo"

chown 0.2000 "/system/xbin/exfatlabel"
chmod 0755 "/system/xbin/exfatlabel"

chown 0.2000 "/system/xbin/exfatvsn"
chmod 0755 "/system/xbin/exfatvsn"

chown 0.2000 "/system/xbin/mkexfat"
chmod 0755 "/system/xbin/mkexfat"

ln -s "mkexfat" "/system/xbin/mkexfatfs"
ln -s "mkexfat" "/system/xbin/mkfs.exfat"

chcon -hR u:object_r:mkfs_exec:s0 "/system/xbin/mkexfat"

chown 0.2000 "/system/xbin/mount.exfat-fuse"
chmod 0755 "/system/xbin/mount.exfat-fuse"

ln -s "mount.exfat-fuse" "/system/xbin/mount.exfat"

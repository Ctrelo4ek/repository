#!/system/bin/sh

# SHELL SCRIPT (SH)

name="exfatprogs"
version="1.2.7"

# 1.2.7

chown 0.0 "/system/lib64/libexfat.so"
chmod 0644 "/system/lib64/libexfat.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libexfat.so"

chown 0.2000 "/system/xbin/fsck.exfat"
chmod 0755 "/system/bin/fsck.exfat"

ln -s "fsck.exfat" "/system/xbin/exfatfsck"

chcon -hR u:object_r:fsck_exec:s0 "/system/xbin/fsck.exfat"

chown 0.2000 "/system/xbin/mkfs.exfat"
chmod 0755 "/system/bin/mkfs.exfat"

ln -s "mkfs.exfat" "/system/xbin/mkexfat"

chcon -hR u:object_r:mkfs_exec:s0 "/system/xbin/mkfs.exfat"

chown 0.2000 "/system/xbin/tune.exfat"
chmod 0755 "/system/bin/tune.exfat"

ln -s "tune.exfat" "/system/xbin/mount.exfat"

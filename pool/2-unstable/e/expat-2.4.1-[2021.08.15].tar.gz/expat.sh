#!/system/bin/sh

# SHELL SCRIPT (SH)

name="expat"
version="2.4.1 [2021.08.15]"

# 2.4.1 [2021.08.15]

source="Termux Make"

chown 0.2000 "/system/xbin/expat-test"
chmod 0755 "/system/xbin/expat-test"

chown 0.2000 "/system/xbin/xmlwf"
chmod 0755 "/system/xbin/xmlwf"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="entr"
version="4.8 [2021.08.19]"

# 4.8 [2021.08.19]

source="Termux Make"

chown 0.2000 "/system/xbin/entr"
chmod 0755 "/system/xbin/entr"

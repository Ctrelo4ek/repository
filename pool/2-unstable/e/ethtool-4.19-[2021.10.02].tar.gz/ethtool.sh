#!/system/bin/sh

# SHELL SCRIPT (SH)

name="ethtool"
version="4.19 [2021.10.02]"

# 4.19 [2021.10.02]

source="Termux Make"

chown 0.2000 "/system/xbin/ethtool"
chmod 0755 "/system/xbin/ethtool"

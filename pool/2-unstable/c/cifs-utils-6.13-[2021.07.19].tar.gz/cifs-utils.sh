#!/system/bin/sh

# SHELL SCRIPT (SH)

name="cifs-utils"
version="6.13 [2021.07.19]"

# 6.13 [2021.07.19]

source="Termux Make"

chown -hR 0.2000 "/system/etc/request-key.d"
chmod -R 0755 "/system/etc/request-key.d"

find "/system/etc/request-key.d" -type d \( -exec chown -h 0.2000 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.2000 {} + -exec chmod 0755 {} + \)

ln -s "../../etc/request-key.d" "/system/usr/share/request-key.d"

chown 0.2000 "/system/xbin/cifs.upcall"
chmod 0755 "/system/xbin/cifs.upcall"

chown 0.2000 "/system/xbin/mount.cifs"
chmod 0755 "/system/xbin/mount.cifs"

ln -s "mount.cifs" "/system/xbin/mount.smb3"

chown 0.2000 "/system/xbin/smbinfo"
chmod 0755 "/system/xbin/smbinfo"

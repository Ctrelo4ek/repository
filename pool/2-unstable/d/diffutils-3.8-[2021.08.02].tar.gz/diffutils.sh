#!/system/bin/sh

# SHELL SCRIPT (SH)

name="diffutils"
version="3.8 [2021.08.02]"

# 3.8 [2021.08.02]

source="Termux Make"
source_2="https://github.com/Zackptg5/Cross-Compiled-Binaries-Android"

chown 0.2000 "/system/xbin/cmp"
chmod 0755 "/system/xbin/cmp"

chown 0.2000 "/system/xbin/diff"
chmod 0755 "/system/xbin/diff"

chown 0.2000 "/system/xbin/diff3"
chmod 0755 "/system/xbin/diff3"

chown 0.2000 "/system/xbin/sdiff"
chmod 0755 "/system/xbin/sdiff"

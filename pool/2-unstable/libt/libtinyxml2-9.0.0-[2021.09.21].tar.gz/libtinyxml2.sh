#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libtinyxml2"
version="9.0.0 [2021.09.21]"

# 9.0.0

source="Termux"

chown 0.0 "/system/lib/libtinyxml2.so"
chmod 0644 "/system/lib/libtinyxml2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libtinyxml2.so"

# 9.0.0 [2021.09.21]

source_2="Termux Make"

chown 0.0 "/system/lib64/libtinyxml2.so"
chmod 0644 "/system/lib64/libtinyxml2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libtinyxml2.so"

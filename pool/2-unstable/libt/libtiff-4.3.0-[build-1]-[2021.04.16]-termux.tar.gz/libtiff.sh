#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libtiff"
version="4.3.0 [Build 1] [2021.04.16]"

# 4.3.0 [Build 1] [2021.04.16]

source="Termux"

chown 0.0 "/system/lib/libtiff.so"
chmod 0644 "/system/lib/libtiff.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libtiff.so"

chown 0.0 "/system/lib/libtiffxx.so"
chmod 0644 "/system/lib/libtiffxx.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libtiffxx.so"

chown 0.0 "/system/lib64/libtiff.so"
chmod 0644 "/system/lib64/libtiff.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libtiff.so"

chown 0.0 "/system/lib64/libtiffxx.so"
chmod 0644 "/system/lib64/libtiffxx.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libtiffxx.so"

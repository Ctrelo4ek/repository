#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libtar"
version="1.2.20 [2021.09.21]"

# 1.2.20 [2021.09.21]

source="Termux Make"

chown 0.0 "/system/lib64/libtar.so"
chmod 0644 "/system/lib64/libtar.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libtar.so"

chown 0.2000 "/system/xbin/libtar"
chmod 0755 "/system/xbin/libtar"

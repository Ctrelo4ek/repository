# FvwmCommand.sh
# Collection of fvwm builtin commands for FvwmCommand
#
alias FvwmCommand='/data/data/com.termux/files/usr/bin/FvwmCommand'
AM () { 
	FvwmCommand "+ $*"
}

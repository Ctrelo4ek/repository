#!/system/bin/sh

# SHELL SCRIPT (SH)

name="freetype2"
version="2.11.0 [2021.08.02]"

# 2.11.0 [2021.08.02]

source="Termux Make"

chown 0.0 "/system/lib/libfreetype.so"
chmod 0644 "/system/lib/libfreetype.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libfreetype.so"

chown 0.0 "/system/lib64/libfreetype.so"
chmod 0644 "/system/lib64/libfreetype.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libfreetype.so"

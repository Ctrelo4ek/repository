#!/system/bin/sh

# SHELL SCRIPT (SH)

name="f2c"
version="20200916 [2021.08.19]"

# 20200916 [2021.08.19]

source="Termux Make"

chown 0.0 "/system/aarch64-linux-android"
chmod 0755 "/system/aarch64-linux-android"

chown 0.2000 "/system/aarch64-linux-android/bin"
chmod 0755 "/system/aarch64-linux-android/bin"

chown 0.2000 "/system/xbin/f2c"
chmod 0755 "/system/xbin/f2c"

ln -s "../../xbin/f2c" "/system/aarch64-linux-android/bin/f2c"

chown 0.2000 "/system/xbin/xsum"
chmod 0755 "/system/xbin/xsum"

ln -s "../../xbin/xsum" "/system/aarch64-linux-android/bin/xsum"

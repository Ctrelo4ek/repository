#!/system/bin/sh

# SHELL SCRIPT (SH)

name="findutils"
version="4.8.0.1 [2021.01.10]"

# 4.8.0.1 [2021.01.10]

source="Termux Make"

chown 0.0 "/system/etc/updatedb.conf"
chmod 0644 "/system/etc/updatedb.conf"

chown 0.2000 "/system/libexec"
chmod 0755 "/system/libexec"

chown 0.2000 "/system/xbin/bigram"
chmod 0755 "/system/xbin/bigram"

chown 0.2000 "/system/xbin/code"
chmod 0755 "/system/xbin/code"

chown 0.2000 "/system/xbin/find"
chmod 0755 "/system/xbin/find"

chown 0.2000 "/system/xbin/frcode"
chmod 0755 "/system/xbin/frcode"

ln -s "../xbin/frcode" "/system/libexec/frcode"

chown 0.2000 "/system/xbin/locate"
chmod 0755 "/system/xbin/locate"

chown 0.2000 "/system/xbin/updatedb"
chmod 0755 "/system/xbin/updatedb"

ln -s "updatedb" "/system/xbin/update.db"

chown 0.2000 "/system/xbin/xargs"
chmod 0755 "/system/xbin/xargs"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="ossp-uuid"
version="1.6.2"

# 1.6.2

source="Termux"

chown 0.0 "/system/lib/libossp-uuid.so"
chmod 0644 "/system/lib/libossp-uuid.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libossp-uuid.so"

chown 0.0 "/system/lib64/libossp-uuid.so"
chmod 0644 "/system/lib64/libossp-uuid.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libossp-uuid.so"

chown 0.2000 "/system/xbin/uuid"
chmod 0755 "/system/xbin/uuid"

chown 0.2000 "/system/xbin/uuid-config"
chmod 0755 "/system/xbin/uuid-config"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="openssh"
version="8.7 P 1 [2021.08.22]"

# 8.7 P 1 [2021.08.22]

source="Termux Make"

chown -hR 0.0 "/system/etc/ssh"
chmod -R 0644 "/system/etc/ssh"

find "/system/etc/ssh" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/ssh" "/system/usr/share/ssh"

chown 0.0 "/system/etc/passwd"
chmod 0644 "/system/etc/passwd"

chown 0.2000 "/system/libexec"
chmod 0755 "/system/libexec"

chown 0.2000 "/system/xbin/opensshd"
chmod 0755 "/system/xbin/opensshd"

chown 0.2000 "/system/xbin/passwd"
chmod 0755 "/system/xbin/passwd"

chown 0.2000 "/system/xbin/scp"
chmod 0755 "/system/xbin/scp"

chown 0.2000 "/system/xbin/scp.bin"
chmod 0755 "/system/xbin/scp.bin"

chown 0.2000 "/system/xbin/sftp"
chmod 0755 "/system/xbin/sftp"

chown 0.2000 "/system/xbin/sftp-server"
chmod 0755 "/system/xbin/sftp-server"

ln -s "../xbin/sftp-server" "/system/libexec/sftp-server"

chown 0.2000 "/system/xbin/sftpa"
chmod 0755 "/system/xbin/sftpa"

chown 0.2000 "/system/xbin/source-ssh-agent"
chmod 0755 "/system/xbin/source-ssh-agent"

chown 0.2000 "/system/xbin/ssh"
chmod 0755 "/system/xbin/ssh"

chown 0.2000 "/system/xbin/ssh.bin"
chmod 0755 "/system/xbin/ssh.bin"

chown 0.2000 "/system/xbin/ssh-add"
chmod 0755 "/system/xbin/ssh-add"

chown 0.2000 "/system/xbin/ssh-agent"
chmod 0755 "/system/xbin/ssh-agent"

chown 0.2000 "/system/xbin/ssh-auto"
chmod 0755 "/system/xbin/ssh-auto"

chown 0.2000 "/system/xbin/ssh-keygen"
chmod 0755 "/system/xbin/ssh-keygen"

ln -s "../xbin/ssh-keysign" "/system/libexec/ssh-keysign"

chown 0.2000 "/system/xbin/ssh-keygen.bin"
chmod 0755 "/system/xbin/ssh-keygen.bin"

chown 0.2000 "/system/xbin/ssh-keyscan"
chmod 0755 "/system/xbin/ssh-keyscan"

chown 0.2000 "/system/xbin/ssh-keysign"
chmod 0755 "/system/xbin/ssh-keysign"

chown 0.2000 "/system/xbin/ssh-pkcs11-helper"
chmod 0755 "/system/xbin/ssh-pkcs11-helper"

ln -s "../xbin/ssh-pkcs11-helper" "/system/libexec/ssh-pkcs11-helper"

chown 0.2000 "/system/xbin/ssh-sk-helper"
chmod 0755 "/system/xbin/ssh-sk-helper"

ln -s "../xbin/ssh-sk-helper" "/system/libexec/ssh-sk-helper"

chown 0.2000 "/system/xbin/ssha"
chmod 0755 "/system/xbin/ssha"

chown 0.2000 "/system/xbin/sshd"
chmod 0755 "/system/xbin/sshd"

chcon -hR u:object_r:sshd_exec:s0 "/system/xbin/sshd"

chown 0.2000 "/system/xbin/sshd.bin"
chmod 0755 "/system/xbin/sshd.bin"

chown 0.2000 "/system/xbin/start-ssh"
chmod 0755 "/system/xbin/start-ssh"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="oathtool [oath-toolkit]"
version="2.6.7 [2021.08.17]"

# 2.6.7 [2021.08.17]

source="Termux Make"

chown -hR 0.0 "/system/etc/xml"
chmod -R 0644 "/system/etc/xml"

find "/system/etc/xml" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/xml" "/system/usr/share/xml"

chown 0.0 "/system/lib/liboath.so"
chmod 0644 "/system/lib/liboath.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/liboath.so"

chown 0.0 "/system/lib/libpskc.so"
chmod 0644 "/system/lib/libpskc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libpskc.so"

chown 0.0 "/system/lib64/liboath.so"
chmod 0644 "/system/lib64/liboath.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/liboath.so"

chown 0.0 "/system/lib64/libpskc.so"
chmod 0644 "/system/lib64/libpskc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpskc.so"

chown 0.2000 "/system/xbin/oathtool"
chmod 0755 "/system/xbin/oathtool"

chown 0.2000 "/system/xbin/pskctool"
chmod 0755 "/system/xbin/pskctool"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libwebp"
version="1.2.1 [2021.08.21]"

# 1.2.1 [2021.10.14]

source="Termux"

chown 0.0 "/system/lib/libwebp.so"
chmod 0644 "/system/lib/libwebp.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libwebp.so"

chown 0.0 "/system/lib/libwebpdecoder.so"
chmod 0644 "/system/lib/libwebpdecoder.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libwebpdecoder.so"

chown 0.0 "/system/lib/libwebpdemux.so"
chmod 0644 "/system/lib/libwebpdemux.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libwebpdemux.so"

chown 0.0 "/system/lib/libwebpmux.so"
chmod 0644 "/system/lib/libwebpmux.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libwebpmux.so"

# 1.2.1 [2021.08.21]

source_2="Termux Make"

chown 0.0 "/system/lib64/libwebp.so"
chmod 0644 "/system/lib64/libwebp.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libwebp.so"

chown 0.0 "/system/lib64/libwebpdecoder.so"
chmod 0644 "/system/lib64/libwebpdecoder.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libwebpdecoder.so"

chown 0.0 "/system/lib64/libwebpdemux.so"
chmod 0644 "/system/lib64/libwebpdemux.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libwebpdemux.so"

chown 0.0 "/system/lib64/libwebpmux.so"
chmod 0644 "/system/li64b/libwebpmux.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libwebpmux.so"

chown 0.2000 "/system/xbin/cwebp"
chmod 0755 "/system/xbin/cwebp"

chown 0.2000 "/system/xbin/dwebp"
chmod 0755 "/system/xbin/dwebp"

chown 0.2000 "/system/xbin/gif2webp"
chmod 0755 "/system/xbin/gif2webp"

chown 0.2000 "/system/xbin/img2webp"
chmod 0755 "/system/xbin/img2webp"

chown 0.2000 "/system/xbin/webpinfo"
chmod 0755 "/system/xbin/webpinfo"

chown 0.2000 "/system/xbin/webpmux"
chmod 0755 "/system/xbin/webpmux"

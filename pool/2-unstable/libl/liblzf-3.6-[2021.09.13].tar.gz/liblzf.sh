#!/system/bin/sh

# SHELL SCRIPT (SH)

name="liblzf"
version="3.6 [2021.09.13]"

# 3.6 [2021.09.13]

source="Termux Make"

chown 0.2000 "/system/xbin/lzf"
chmod 0755 "/system/xbin/lzf"

ln -s "lzf" "/system/xbin/lzcat"
ln -s "lzf" "/system/xbin/lzfcat"
ln -s "lzf" "/system/xbin/unlzf"

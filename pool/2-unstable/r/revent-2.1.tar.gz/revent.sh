#!/system/bin/sh

# SHELL SCRIPT (SH)

name="revent"
version="2.1"

# 2.1

chown 0.2000 "/system/xbin/revent"
chmod 0755 "/system/xbin/revent"

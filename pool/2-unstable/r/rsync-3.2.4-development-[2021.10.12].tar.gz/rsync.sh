#!/system/bin/sh

# SHELL SCRIPT (SH)

name="rsync"
version="3.2.4 Development [2021.10.12]"

# 3.2.4 Development [2021.10.12]

source="Termux Make"

chown 0.2000 "/system/xbin/rsync"
chmod 0755 "/system/xbin/rsync"

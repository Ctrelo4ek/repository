#!/system/bin/sh

# SHELL SCRIPT (SH)

name="re2c"
version="2.2 [2021.08.04]"

# 2.2 [2021.08.04]

source="Termux Make"

chown 0.0 "/system/aarch64-linux-android"
chmod 0755 "/system/aarch64-linux-android"

chown 0.2000 "/system/aarch64-linux-android/bin"
chmod 0755 "/system/aarch64-linux-android/bin"

chown 0.2000 "/system/xbin/re2c"
chmod 0755 "/system/xbin/re2c"

ln -s "../../xbin/re2c" "/system/aarch64-linux-android/bin/re2c"

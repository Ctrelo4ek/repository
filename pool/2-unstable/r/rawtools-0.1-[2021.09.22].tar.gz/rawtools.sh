#!/system/bin/sh

# SHELL SCRIPT (SH)

name="rawtools"
version="0.1 [2021.01.27]"

# 0.1 [2021.01.27]

source="Termux Make"

chown 0.2000 "/system/xbin/rawflt2u1"
chmod 0755 "/system/xbin/rawflt2u1"

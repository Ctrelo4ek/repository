#!/data/data/com.termux/files/usr/bin/env python
# -*- coding: utf-8 -*-
#
{fileheader}

def main(args):
    return 0

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))

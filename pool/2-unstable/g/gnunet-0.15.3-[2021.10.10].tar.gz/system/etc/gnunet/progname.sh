progname=${0##*/}

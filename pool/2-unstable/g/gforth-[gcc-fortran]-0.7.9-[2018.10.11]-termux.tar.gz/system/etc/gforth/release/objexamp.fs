\ examples and tests for objects.fs

\ written by Anton Ertl 1996-1998
\ public domain

\ load these files separately for testing persistence across image generation
require objex1.fs
require objex2.fs

\ or load objex1.fs, then save; and when running the new image, load objex2.fs

: version-string s" 0.7.9-20120730" ;

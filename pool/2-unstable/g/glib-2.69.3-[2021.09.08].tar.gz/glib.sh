#!/system/bin/sh

# SHELL SCRIPT (SH)

name="glib"
version="2.69.3 [2021.09.08]"

# 2.69.3 [2021.09.08]

source="Termux Make"

chown 0.0 "/system/lib/libgio-2.0.so"
chmod 0644 "/system/lib/libgio-2.0.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgio-2.0.so"

chown 0.0 "/system/lib/libglib-2.0.so"
chmod 0644 "/system/lib/libglib-2.0.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libglib-2.0.so"

chown 0.0 "/system/lib/libgmodule-2.0.so"
chmod 0644 "/system/lib/libgmodule-2.0.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgmodule-2.0.so"

chown 0.0 "/system/lib/libgobject-2.0.so"
chmod 0644 "/system/lib/libgobject-2.0.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgobject-2.0.so"

chown 0.0 "/system/lib/libgthread-2.0.so"
chmod 0644 "/system/lib/libgthread-2.0.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libgthread-2.0.so"

chown 0.0 "/system/lib64/libgio-2.0.so"
chmod 0644 "/system/lib64/libgio-2.0.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgio-2.0.so"

chown 0.0 "/system/lib64/libglib-2.0.so"
chmod 0644 "/system/lib64/libglib-2.0.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libglib-2.0.so"

chown 0.0 "/system/lib64/libgmodule-2.0.so"
chmod 0644 "/system/lib64/libgmodule-2.0.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgmodule-2.0.so"

chown 0.0 "/system/lib64/libgobject-2.0.so"
chmod 0644 "/system/lib64/libgobject-2.0.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgobject-2.0.so"

chown 0.0 "/system/lib64/libgthread-2.0.so"
chmod 0644 "/system/lib64/libgthread-2.0.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libgthread-2.0.so"

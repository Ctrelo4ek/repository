#!/system/bin/sh

# SHELL SCRIPT (SH)

name="gsl"
version="2.7 [2021.08.19]"

# 2.7 [2021.08.19]

source="Termux Make"

chown 0.0 "/system/aarch64-linux-android"
chmod 0755 "/system/aarch64-linux-android"

chown 0.2000 "/system/aarch64-linux-android/bin"
chmod 0755 "/system/aarch64-linux-android/bin"

chown 0.2000 "/system/xbin/gsl-config"
chmod 0755 "/system/xbin/gsl-config"

ln -s "../../xbin/gsl-config" "/system/aarch64-linux-android/bin/gsl-config"

chown 0.2000 "/system/xbin/gsl-histogram"
chmod 0755 "/system/xbin/gsl-histogram"

ln -s "../../xbin/gsl-histogram" "/system/aarch64-linux-android/bin/gsl-histogram"

chown 0.2000 "/system/xbin/gsl-randist"
chmod 0755 "/system/xbin/gsl-randist"

ln -s "../../xbin/gsl-randist" "/system/aarch64-linux-android/bin/gsl-randist"

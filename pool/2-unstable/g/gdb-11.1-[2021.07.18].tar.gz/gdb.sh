#!/system/bin/sh

# SHELL SCRIPT (SH)

name="gdb"
version="11.1 [2021.07.18]"

# 11.1 [2021.07.18]

source="Termux Make"

chown 0.0 "/system/aarch64-linux-android"
chmod 0755 "/system/aarch64-linux-android"

chown 0.2000 "/system/aarch64-linux-android/bin"
chmod 0755 "/system/aarch64-linux-android/bin"

chown 0.2000 "/system/xbin/gdb"
chmod 0755 "/system/xbin/gdb"

ln -s "../../xbin/gdb" "/system/aarch64-linux-android/bin/gdb"

chown 0.2000 "/system/xbin/gdb64"
chmod 0755 "/system/xbin/gdb64"

ln -s "../../xbin/gdb64" "/system/aarch64-linux-android/bin/gdb64"

chown 0.2000 "/system/xbin/gdb-add-index"
chmod 0755 "/system/xbin/gdb-add-index"

ln -s "../../xbin/gdb-add-index" "/system/aarch64-linux-android/bin/gdb-add-index"

chown 0.2000 "/system/xbin/gdbserver"
chmod 0755 "/system/xbin/gdbserver"

ln -s "../../xbin/gdbserver" "/system/aarch64-linux-android/bin/gdbserver"

chown 0.2000 "/system/xbin/gdbserver64"
chmod 0755 "/system/xbin/gdbserver64"

ln -s "../../xbin/gdbserver64" "/system/aarch64-linux-android/bin/gdbserver64"

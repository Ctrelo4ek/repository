#!/system/bin/sh

# SHELL SCRIPT (SH)

name="gptfdisk"
version="1.0.8 [2021.09.06]"

# 1.0.4

source="Android"

chown 0.2000 "/system/bin/sgdisk"
chmod 0755 "/system/bin/sgdisk"

chcon -hR u:object_r:sgdisk_exec:s0 "/system/bin/sgdisk"

# 1.0.8 [2021.09.06]

chown 0.2000 "/system/xbin/cgdisk"
chmod 0755 "/system/xbin/cgdisk"

chown 0.2000 "/system/xbin/fixparts"
chmod 0755 "/system/xbin/fixparts"

chown 0.2000 "/system/xbin/gdisk"
chmod 0755 "/system/xbin/gdisk"

chown 0.2000 "/system/xbin/sgdisk"
chmod 0755 "/system/xbin/sgdisk"

chcon -hR u:object_r:sgdisk_exec:s0 "/system/xbin/sgdisk"

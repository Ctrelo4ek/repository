#!/system/bin/sh

# SHELL SCRIPT (SH)

name="gtcycles"
version="1.1 [2021.07.20]"

# 1.1 [2021.07.20]

source="Termux Make"

chown 0.2000 "/system/xbin/gtcycles"
chmod 0755 "/system/xbin/gtcycles"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="grep"
version="3.7 [2021.08.15]"

# 2.5.1 Free BSD

source="Android"

chown 0.2000 "/system/bin/grep"
chmod 0755 "/system/bin/grep"

ln -s "grep" "/system/bin/egrep"
ln -s "grep" "/system/bin/fgrep"

chcon -hR u:object_r:grep_exec:s0 "/system/bin/grep"

# 3.7 [2021.08.15]

source_2="Termux Make"

chown 0.2000 "/system/xbin/egrep"
chmod 0755 "/system/xbin/egrep"

chcon -hR u:object_r:grep_exec:s0 "/system/xbin/egrep"

chown 0.2000 "/system/xbin/fgrep"
chmod 0755 "/system/xbin/fgrep"

chcon -hR u:object_r:grep_exec:s0 "/system/xbin/fgrep"

chown 0.2000 "/system/xbin/grep"
chmod 0755 "/system/xbin/grep"

# ln -s "grep" "/system/xbin/egrep"
# ln -s "grep" "/system/xbin/fgrep"

chcon -hR u:object_r:grep_exec:s0 "/system/xbin/grep"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="zsh"
version="5.8.0 [0]"

# 5.8.0 [0]

source="https://github.com/Zackptg5/GNU-Utils-Android"
source_2="https://github.com/romkatv/zsh-bin"

chown -hR 0.0 "/system/etc/zsh"
chmod -R 0644 "/system/etc/zsh"

find "/system/etc/zsh" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "zsh/zlogin" "/system/etc/zlogin"
ln -s "zsh/zlogout" "/system/etc/zlogout"
ln -s "zsh/zprofile" "/system/etc/zprofile"
ln -s "zsh/zshenv" "/system/etc/zshenv"
ln -s "zsh/zshrc" "/system/etc/zshrc"

ln -s "../../etc/zsh" "/system/usr/share/zsh"

chown 0.0 "/system/etc/environment"
chmod 0644 "/system/etc/environment"

chown 0.0 "/system/etc/mkshrc"
chmod 0644 "/system/etc/mkshrc"

chown 0.2000 "/system/etc/shells"
chmod 0755 "/system/etc/shells"

chown 0.2000 "/system/xbin/zsh"
chmod 0755 "/system/xbin/zsh"

chcon -hR u:object_r:shell_exec:s0 "/system/xbin/zsh"

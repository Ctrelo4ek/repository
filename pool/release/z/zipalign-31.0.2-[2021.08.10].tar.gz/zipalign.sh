#!/system/bin/sh

# SHELL SCRIPT (SH)

name="zipalign"
version="31.0.2 [2021.08.10]"

# 31.0.2 [2021.08.10]

source="Android SDK"

chown 0.2000 "/system/xbin/zipalign"
chmod 0755 "/system/xbin/zipalign"

chown 0.2000 "/system/xbin/zipalign.bin"
chmod 0755 "/system/xbin/zipalign.bin"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="convert_utf"
version="1.3 [2021.09.21]"

# 1.3 [2021.09.21]

source="Termux Make"

chown 0.0 "/system/lib64/libconvert_utf.so"
chmod 0644 "/system/lib64/libconvert_utf.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libconvert_utf.so"

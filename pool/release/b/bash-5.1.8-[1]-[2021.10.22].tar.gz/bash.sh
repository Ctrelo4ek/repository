#!/system/bin/sh

# SHELL SCRIPT (SH)

name="bash"
version="5.1.8 [1] [2021.10.22]"

# 5.1.8 [1] [2021.10.22]

source="https://github.com/ianmacd/bash-aarch64"
source_2="https://github.com/Zackptg5/GNU-Utils-Android"
source_3="https://github.com/henriknelson/bash-magisk-module"
source_4="https://http.kali.org/pool/main/b/bash"
source_5="https://mirror.yandex.ru/debian/pool/main/b/bash"

chown 0.2000 "/system/bin/bash"
chmod 0755 "/system/bin/bash"

ln -s "bash" "/system/bin/rbash"

chcon -hR u:object_r:shell_exec:s0 "/system/bin/bash"

chown 0.2000 "/system/bin/bashbug"
chmod 0755 "/system/bin/bashbug"

chown -hR 0.0 "/system/etc/bash"
chmod -R 0644 "/system/etc/bash"

find "/system/etc/bash" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "bash/bashrc" "/system/etc/bashrc"
ln -s "bash/color" "/system/etc/DIR_COLORS"
ln -s "bash/color" "/system/etc/dir_colors"
ln -s "bash/motd" "/system/etc/motd"
ln -s "bash/logout" "/system/etc/bash_logout"
ln -s "bash/logout" "/system/etc/logout"
ln -s "bash/profile" "/system/etc/bash_login"
ln -s "bash/profile" "/system/etc/bash_profile"
ln -s "bash/profile" "/system/etc/profile"

ln -s "../../etc/bash" "/system/usr/share/bash"

chown -hR 0.2000 "/system/etc/profile.d"
chmod -R 0755 "/system/etc/profile.d"

find "/system/etc/profile.d" -type d \( -exec chown -h 0.2000 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.2000 {} + -exec chmod 0755 {} + \)

ln -s "../../etc/profile.d" "/system/usr/share/profile.d"

chown 0.0 "/system/etc/environment"
chmod 0644 "/system/etc/environment"

chown 0.0 "/system/etc/mkshrc"
chmod 0644 "/system/etc/mkshrc"

chown 0.2000 "/system/etc/shells"
chmod 0755 "/system/etc/shells"

# 5.1.8 [1]

source_2="Termux"

chown -hR 0.0 "/system/lib/bash"
chmod -R 0644 "/system/lib/bash"

find "/system/lib/bash" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../lib/bash" "/system/lib64/bash"

chcon -hR u:object_r:shell_exec:s0 "/system/lib/bash"

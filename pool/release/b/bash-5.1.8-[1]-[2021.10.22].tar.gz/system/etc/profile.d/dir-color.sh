# /system/etc/profile.d/dir-color

# Цветные стили

if [ -x "/system/xbin/dircolors" ]; then
	LS_COLORS=""
	if [ -f "/system/etc/bash/color" ]; then
		eval $( dircolors -b "/system/etc/bash/color" )
	else
		if [ -f "/system/etc/DIR_COLORS" ]; then
			eval $( dircolors -b "/system/etc/DIR_COLORS" )
		else
			if [ -f "/system/etc/dir_colors" ]; then
				eval $( dircolors -b "/system/etc/dir_colors" )
			else
				eval $( dircolors -b )
			fi
		fi
	fi
fi

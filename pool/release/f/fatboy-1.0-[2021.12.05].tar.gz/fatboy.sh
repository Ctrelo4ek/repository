#!/system/bin/sh

# SHELL SCRIPT (SH)

name="fatboy"
version="1.0 [2021.12.05]"

# 1.0 [2021.12.05]

source="Termux Make"

chown 0.2000 "/system/xbin/fatboy"
chmod 0755 "/system/xbin/fatboy"

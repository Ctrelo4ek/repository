#!/system/bin/sh

# SHELL SCRIPT (SH)

name="hyperfine"
version="1.12.0 [2021.10.17]"

# 1.12.0 [2021.10.17]

source="Termux"
source_2="https://github.com/henriknelson/hyperfine-magisk-module"

chown 0.2000 "/system/xbin/hyperfine"
chmod 0755 "/system/xbin/hyperfine"

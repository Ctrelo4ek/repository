#!/system/bin/sh

# SHELL SCRIPT (SH)

name="bat"
version="0.18."

# 0.18.1

source="https://github.com/henriknelson/bat-magisk-module"

chown -hR 0.0 "/system/etc/bat"
chmod -R 0644 "/system/etc/bat"

find "/system/etc/bat" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/bat" "/system/usr/share/bat"

chown 0.2000 "/system/xbin/bat"
chmod 0755 "/system/xbin/bat"

chown 0.2000 "/system/xbin/bat.bin"
chmod 0755 "/system/xbin/bat.bin"

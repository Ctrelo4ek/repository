#!/system/bin/sh

# SHELL SCRIPT (SH)

name="aria2c"
version="1.36.0 [2021.11.10]"

# 1.36.0 [2021.11.10]

chown 0.0 "/system/etc/aria2.conf"
chmod 0644 "/system/etc/aria2.conf"

chown 0.0 "/system/etc/aria2-tracker.conf"
chmod 0644 "/system/etc/aria2-tracker.conf"

chown 0.2000 "/system/xbin/aria2c"
chmod 0755 "/system/xbin/aria2c"

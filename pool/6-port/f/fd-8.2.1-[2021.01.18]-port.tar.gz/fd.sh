#!/system/bin/sh

# SHELL SCRIPT (SH)

name="fd"
version="8.2.1 [2021.01.18]"

# 8.2.1 [2021.01.18]

source="https://github.com/henriknelson/fd-magisk-module"

chown 0.2000 "/system/xbin/fd"
chmod 0755 "/system/xbin/fd"

chown 0.2000 "/system/xbin/fd.bin"
chmod 0755 "/system/xbin/fd.bin"

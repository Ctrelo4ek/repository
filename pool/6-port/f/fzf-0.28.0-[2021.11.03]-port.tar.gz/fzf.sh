#!/system/bin/sh

# SHELL SCRIPT (SH)

name="fzf"
version="0.28.0 [2021.11.03]"

# 0.28.0 [2021.11.03]

source="Termux"
source_2="https://github.com/henriknelson/fzf-magisk-module"

chown 0.2000 "/system/xbin/fzf"
chmod 0755 "/system/xbin/fzf"

chown 0.2000 "/system/xbin/fzf-tmux"
chmod 0755 "/system/xbin/fzf-tmux"

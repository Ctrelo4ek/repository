#!/system/bin/sh

# SHELL SCRIPT (SH)

name="exa"
version="0.10.1"

# 0.10.1

source="Termux"

chown 0.2000 "/system/xbin/exa"
chmod 0755 "/system/xbin/exa"

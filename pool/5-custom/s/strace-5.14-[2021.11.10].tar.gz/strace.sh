#!/system/bin/sh

# SHELL SCRIPT (SH)

name="strace"
version="5.14 [2021.11.10]"

# 5.14 [2021.11.10]

source="https://github.com/Zackptg5/Cross-Compiled-Binaries-Android"
source_2="https://github.com/henriknelson/strace-magisk-module"

chown 0.2000 "/system/xbin/strace"
chmod 0755 "/system/xbin/strace"

chown 0.2000 "/system/xbin/strace-log-merge"
chmod 0755 "/system/xbin/strace-log-merge"

export TMUX_TMPDIR="/data/local/.config/tmux/tmp"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="tmux"
version="3.5 Next [2021.11.10]"

# 3.5 Next [2021.11.10]

source="https://github.com/romkatv/tmux-bin"
source_2="https://androidfilehost.com/?fid=6006931924117906661"

chown -hR 0.2000 "/system/etc/profile.d"
chmod -R 0755 "/system/etc/profile.d"

find "/system/libexec/profile.d" -type d \( -exec chown -h 0.2000 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.2000 {} + -exec chmod 0755 {} + \)

ln -s "../../etc/profile.d" "/system/usr/share/profile.d"

chown 0.0 "/system/etc/tmux.conf"
chmod 0644 "/system/etc/tmux.conf"

chown 0.2000 "/system/xbin/tmux"
chmod 0755 "/system/xbin/tmux"

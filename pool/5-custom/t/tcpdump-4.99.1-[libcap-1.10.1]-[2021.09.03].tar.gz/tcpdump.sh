#!/system/bin/sh

# SHELL SCRIPT (SH)

name="tcpdump"
version="4.99.1 [libcap 1.10.1] [2021.09.03]"

# 4.9.2 [libcap 1.9.0]

source="Android"

chown 0.2000 "/system/bin/tcpdump"
chmod 0755 "/system/bin/tcpdump"

chcon -hR u:object_r:tcpdump_exec:s0 "/system/bin/tcpdump"

# 4.99.1 [libcap 1.10.1] [2021.09.03]

source_2="Termux Make"
source_3="https://github.com/Zackptg5/GNU-Utils-Android"

chown 0.2000 "/system/xbin/tcpdump"
chmod 0755 "/system/xbin/tcpdump"

chcon -hR u:object_r:tcpdump_exec:s0 "/system/xbin/tcpdump"

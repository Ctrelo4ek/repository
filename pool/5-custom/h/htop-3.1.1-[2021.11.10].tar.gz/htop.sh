#!/system/bin/sh

# SHELL SCRIPT (SH)

name="htop"
version="3.1.1 [2021.11.10]"

# 3.1.1 [2021.11.10]

source="https://github.com/Zackptg5/GNU-Utils-Android"
source_2="https://github.com/henriknelson/htop-magisk-module"
source_3="Termux Make"

chown 0.0 "/system/etc/htoprc"
chmod 0644 "/system/etc/htoprc"

chown 0.2000 "/system/xbin/htop"
chmod 0755 "/system/xbin/htop"

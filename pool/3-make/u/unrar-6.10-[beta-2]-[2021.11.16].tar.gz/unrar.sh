#!/system/bin/sh

# SHELL SCRIPT (SH)

name="unrar"
version="6.10 Beta 2 [2021.11.16]"

# 6.10 Beta 2 [2021.11.16]

source="Termux Make"

chown 0.0 "/system/lib64/libunrar.so"
chmod 0644 "/system/lib64/libunrar.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libunrar.so"

chown 0.2000 "/system/xbin/unrar"
chmod 0755 "/system/xbin/unrar"

ln -s "unrar" "/system/xbin/rar"

chown 0.2000 "/system/xbin/unrar.sfx"
chmod 0755 "/system/xbin/unrar.sfx"

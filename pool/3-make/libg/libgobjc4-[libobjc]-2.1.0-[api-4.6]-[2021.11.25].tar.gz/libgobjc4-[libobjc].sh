#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libgobjc4 [libobjc]"
version="2.1.0 [API 4.6] [2021.11.25]"

# 2.0.0 [API 4.6] [2021.09.12]

chown 0.0 "/system/aarch64-linux-android"
chmod 0755 "/system/aarch64-linux-android"

chown 0.0 "/system/aarch64-linux-android/lib"
chmod 0644 "/system/aarch64-linux-android/lib"

ln -s "lib" "/system/aarch64-linux-android/lib64"

chcon -hR u:object_r:system_lib_file:s0 "/system/aarch64-linux-android/lib"

chown -hR 0.0 "/system/lib/gcc"
chmod -R 0644 "/system/lib/gcc"

find "/system/lib/gcc" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../lib/gcc" "/system/aarch64-linux-android/lib/gcc"
ln -s "../lib/gcc" "/system/lib64/gcc"

chcon -hR u:object_r:system_file:s0 "/system/lib/gcc"

chown 0.0 "/system/lib/libobjc.so"
chmod 0644 "/system/lib/libobjc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libobjc.so"

# 2.1.0 [API 4.6] [2021.11.25]

source_2="Termux Make"

chown 0.0 "/system/lib64/libobjc.so"
chmod 0644 "/system/lib64/libobjc.so"

ln -s "../../../../lib64/libobjc.so" "/system/lib/gcc/aarch64-linux-android/release/libobjc.so"
ln -s "../../lib64/libobjc.so" "/system/aarch64-linux-android/lib/libobjc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libobjc.so"

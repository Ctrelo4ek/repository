#!/system/bin/sh

# SHELL SCRIPT (SH)

name="mksh [mirbsd ksh]"
version="R 59 C 14 [2021.10.15]"

# R 57 [2019.03.01]

source="Android"

chown 0.2000 "/system/bin/sh"
chmod 0755 "/system/bin/sh"

ln -s "sh" "/system/bin/rsh"

chcon -hR u:object_r:shell_exec:s0 "/system/bin/sh"

# R 59 C 14 [2021.10.15]

source_2="https://http.kali.org/pool/main/m/mksh/"
source_3="https://mirror.yandex.ru/debian/pool/main/m/mksh/"

chown 0.2000 "/system/bin/mksh"
chmod 0755 "/system/bin/mksh"

ln -s "mksh" "/system/bin/ksh"
ln -s "mksh" "/system/bin/rksh"
ln -s "mksh" "/system/bin/rmksh"

chcon -hR u:object_r:shell_exec:s0 "/system/bin/mksh"

chown 0.0 "/system/etc/environment"
chmod 0644 "/system/etc/environment"

chown 0.0 "/system/etc/mkshrc"
chmod 0644 "/system/etc/mkshrc"

chown 0.2000 "/system/etc/shells"
chmod 0755 "/system/etc/shells"

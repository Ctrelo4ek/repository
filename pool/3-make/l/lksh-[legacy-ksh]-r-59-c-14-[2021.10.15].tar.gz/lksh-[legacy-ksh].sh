#!/system/bin/sh

# SHELL SCRIPT (SH)

name="lksh [legacy-ksh]"
version="R 59 C 14 [2021.10.15]"

# R 59 C 14 [2021.10.15]

source="https://http.kali.org/pool/main/m/mksh"
source_2="https://mirror.yandex.ru/debian/pool/main/m/mksh"

chown 0.0 "/system/etc/environment"
chmod 0644 "/system/etc/environment"

chown 0.0 "/system/etc/mkshrc"
chmod 0644 "/system/etc/mkshrc"

chown 0.2000 "/system/etc/shells"
chmod 0755 "/system/etc/shells"

chown 0.2000 "/system/xbin/lksh"
chmod 0755 "/system/xbin/lksh"

ln -s "lksh" "/system/xbin/ksh"
ln -s "lksh" "/system/xbin/rksh"
ln -s "lksh" "/system/xbin/rlksh"

chcon -hR u:object_r:shell_exec:s0 "/system/xbin/lksh"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="openssl3-tool"
version="3.0.0 [2021.10.25]"

# 3.0.0 [2021.10.25]

source="https://github.com/Zackptg5/Cross-Compiled-Binaries-Android"
source_2="Termux Make"

chown 0.0 "/system/perl"
chmod 0755 "/system/perl"

chown 0.2000 "/system/perl/bin"
chmod 0755 "/system/perl/bin"

chown 0.2000 "/system/xbin/add-trusted-certificate"
chmod 0755 "/system/xbin/add-trusted-certificate"

chown 0.2000 "/system/xbin/c_rehash"
chmod 0755 "/system/xbin/c_rehash"

ln -s "../../xbin/c_rehash" "/system/perl/bin/c_rehash"

chown 0.2000 "/system/xbin/openssl3"
chmod 0755 "/system/xbin/openssl3"

ln -s "openssl3" "/system/xbin/openssl"
ln -s "openssl3" "/system/xbin/ssl"

chcon -hR u:object_r:openssl_exec:s0 "/system/xbin/openssl3"

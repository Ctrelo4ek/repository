#!/system/bin/sh

# SHELL SCRIPT (SH)

name="openssl"
version="1.1.1 L [2021.08.24]"

# 11.0

source="Android"

chown -hR 0.0 "/system/etc/pkgconfig"
chmod -R 0644 "/system/etc/pkgconfig"

find "/system/etc/pkgconfig" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/pkgconfig" "/system/usr/share/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib64/pkgconfig"

chown -hR 0.0 "/system/etc/security/cacerts"
chmod -R 0644 "/system/etc/security/cacerts"

find "/system/etc/security/cacerts" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/security" "/system/usr/share/security"

chown -hR 0.0 "/system/etc/ssl"
chmod -R 0644 "/system/etc/ssl"

find "/system/etc/ssl" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../security/cacerts/db3a806b.0" "/system/etc/ssl/private/android.pem"
ln -sf "../../security/cacerts/94a40640.0" "/system/etc/ssl/private/borovets.pem"
ln -s "../security/cacerts" "/system/etc/ssl/certs"
ln -s "cert.pem" "/system/etc/ssl/ca-bundle.pem"
ln -s "cert.pem" "/system/etc/ssl/cacert.pem"
ln -s "cert.pem" "/system/etc/ssl/certificate.pem"
ln -s "ssl" "/system/etc/tls"
ln -s "ssl/openssl.cnf" "/system/etc/openssl.cnf"

ln -s "../../etc/ssl" "/system/usr/share/ssl"
ln -s "../../etc/ssl" "/system/usr/share/tls"

chown 0.0 "/system/lib/libcrypto.so"
chmod 0644 "/system/lib/libcrypto.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libcrypto.so"

chown 0.0 "/system/lib/libssl.so"
chmod 0644 "/system/lib/libssl.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libssl.so"

chown 0.0 "/system/lib64/libcrypto.so"
chmod 0644 "/system/lib64/libcrypto.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libcrypto.so"

chown 0.0 "/system/lib64/libssl.so"
chmod 0644 "/system/lib64/libssl.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libssl.so"

# 1.1.1 L [2021.08.24]

source_2="Termux"

chown -hR 0.0 "/system/lib/engines"
chmod -R 0644 "/system/lib/engines"

find "/system/lib/engines" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../lib/engines" "/system/lib64/engines"
ln -s "../lib/engines" "/system/lib64/engines-1.1"
ln -s "engines" "/system/lib/engines-1.1"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/engines"

chown 0.0 "/system/lib/libcrypto_ndk.so"
chmod 0644 "/system/lib/libcrypto_ndk.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/system/lib/libcrypto_ndk.so"

chown 0.0 "/system/lib/libssl_ndk.so"
chmod 0644 "/system/lib/libssl_ndk.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/system/lib/libssl_ndk.so"

chown 0.0 "/system/lib64/libcrypto_ndk.so"
chmod 0644 "/system/lib64/libcrypto_ndk.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/system/lib64/libcrypto_ndk.so"

chown 0.0 "/system/lib64/libssl_ndk.so"
chmod 0644 "/system/lib64/libssl_ndk.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/system/lib64/libssl_ndk.so"

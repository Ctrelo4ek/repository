#!/system/bin/sh

# SHELL SCRIPT (SH)

name="openssl"
version="3.0.0 [2021.10.25]"

# 3.0.0 [2021.10.25]

source="Termux Make"

chown -hR 0.0 "/system/etc/libmap"
chmod -R 0644 "/system/etc/libmap"

find "/system/etc/libmap" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/libmap" "/system/usr/share/libmap"

chown -hR 0.0 "/system/etc/pkgconfig"
chmod -R 0644 "/system/etc/pkgconfig"

find "/system/etc/pkgconfig" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/pkgconfig" "/system/usr/share/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib64/pkgconfig"

chown -hR 0.0 "/system/etc/security/cacerts"
chmod -R 0644 "/system/etc/security/cacerts"

find "/system/etc/security/cacerts" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/security" "/system/usr/share/security"

chown -hR 0.0 "/system/etc/ssl"
chmod -R 0644 "/system/etc/ssl"

find "/system/etc/ssl" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../security/cacerts/db3a806b.0" "/system/etc/ssl/private/android.pem"
ln -sf "../../security/cacerts/94a40640.0" "/system/etc/ssl/private/borovets.pem"
ln -s "../security/cacerts" "/system/etc/ssl/certs"
ln -s "cert.pem" "/system/etc/ssl/ca-bundle.pem"
ln -s "cert.pem" "/system/etc/ssl/cacert.pem"
ln -s "cert.pem" "/system/etc/ssl/certificate.pem"
ln -s "ssl" "/system/etc/tls"
ln -s "ssl/openssl.cnf" "/system/etc/openssl.cnf"

ln -s "../../etc/ssl" "/system/usr/share/ssl"
ln -s "../../etc/ssl" "/system/usr/share/tls"

chown -hR 0.0 "/system/lib/engines"
chmod -R 0644 "/system/lib/engines"

find "/system/lib/engines" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../lib/engines" "/system/lib64/engines"
ln -s "../lib/engines" "/system/lib64/engines-3"
ln -s "engines" "/system/lib/engines-3"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/engines"

chown -hR 0.0 "/system/lib/ossl-modules"
chmod -R 0644 "/system/lib/ossl-modules"

find "/system/lib/ossl-modules" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../ossl-modules/fips.so" "/system/lib/engines/fips.so"
ln -s "../ossl-modules/legacy.so" "/system/lib/engines/legacy.so"

ln -s "../lib/ossl-modules" "/system/lib64/ossl-modules"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/ossl-modules"

chown 0.0 "/system/lib64/libcrypto3.so"
chmod 0644 "/system/lib64/libcrypto3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libcrypto3.so"

chown 0.0 "/system/lib64/libssl3.so"
chmod 0644 "/system/lib64/libssl3.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libssl3.so"

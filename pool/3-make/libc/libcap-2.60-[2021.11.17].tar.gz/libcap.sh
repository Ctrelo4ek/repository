#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libcap"
version="2.60 [2021.11.17]"

# 10.0

source="Android"

chown 0.2000 "/system/bin/getcap"
chmod 0755 "/system/bin/getcap"

chown 0.2000 "/system/bin/setcap"
chmod 0755 "/system/bin/setcap"

# 2.60

source_2="Termux"

chown 0.0 "/system/lib/libcap.so"
chmod 0644 "/system/lib/libcap.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libcap.so"

chown 0.2000 "/system/xbin/capsh"
chmod 0755 "/system/xbin/capsh"

chown 0.2000 "/system/xbin/getcap"
chmod 0755 "/system/xbin/getcap"

chown 0.2000 "/system/xbin/getpcaps"
chmod 0755 "/system/xbin/getpcaps"

chown 0.2000 "/system/xbin/setcap"
chmod 0755 "/system/xbin/setcap"

# 2.60 [2021.11.17]

source_3="Termux Make"

chown 0.0 "/system/lib64/libcap.so"
chmod 0644 "/system/lib64/libcap.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libcap.so"

chown 0.0 "/system/lib64/libpsx.so"
chmod 0644 "/system/lib64/libpsx.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libpsx.so"

chown 0.2000 "/system/xbin/makenames"
chmod 0755 "/system/xbin/makenames"

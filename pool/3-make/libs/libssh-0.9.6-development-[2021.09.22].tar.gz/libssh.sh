#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libssh"
version="0.9.6 Development [2021.09.22]"

# 0.9.6

source="Termux"

chown 0.0 "/system/lib/libssh.so"
chmod 0644 "/system/lib/libssh.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libssh.so"

# 0.9.6 Development [2021.09.22]

source="Termux Make"

chown 0.0 "/system/lib64/libssh.so"
chmod 0644 "/system/lib64/libssh.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libssh.so"

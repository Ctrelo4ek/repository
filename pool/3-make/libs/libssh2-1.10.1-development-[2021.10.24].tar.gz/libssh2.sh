#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libssh2"
version="1.10.1 [2021.10.24]"

# 1.10.0 [2021.11.06]

source="Termux"
source_2="https://github.com/Zackptg5/Curl-For-Android"

chown 0.0 "/system/lib/libssh2.so"
chmod 0644 "/system/lib/libssh2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libssh2.so"

# 1.10.1 [2021.10.24]

source_3="Termux Make"

chown 0.0 "/system/lib64/libssh2.so"
chmod 0644 "/system/lib64/libssh2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libssh2.so"

XML2_LIBDIR="-L/system/lib64"
XML2_LIBS="-lxml2 -llzma -liconva -lm"
XML2_INCLUDEDIR="-I/system/include/libxml2"

MODULE_VERSION="xml2-2.9.12"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libxml2"
version="2.9.12 [2021.11.25]"

# 2.9.12 [Build 1] [2021.10.09]

source="Termux"

chown 0.0 "/system/lib/libxml2.so"
chmod 0644 "/system/lib/libxml2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libxml2.so"

# 2.9.12 [2021.11.25]

source_2="Termux Make"

chown 0.0 "/system/lib/xml2Conf.sh"
chmod 0644 "/system/lib/xml2Conf.sh"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/xml2Conf.sh"

chown 0.0 "/system/lib64/libxml2.so"
chmod 0644 "/system/lib64/libxml2.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libxml2.so"

chown 0.2000 "/system/xbin/xml2-config"
chmod 0755 "/system/xbin/xml2-config"

XSLT_LIBDIR="-L/system/lib64"
XSLT_LIBS="-lxslt -lxml2 -lz -llzma -liconv -lm"
XSLT_PRIVATE_LIBS="-lm"
XSLT_INCLUDEDIR="-I/system/include"

MODULE_VERSION="xslt-1.1.34"

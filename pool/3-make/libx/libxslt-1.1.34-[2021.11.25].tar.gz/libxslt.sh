#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libxslt"
version="1.1.34 [2021.11.25]"

# 1.1.34 [Build 1] [2021.07.05]

source="Termux"

chown 0.0 "/system/lib/libexslt.so"
chmod 0644 "/system/lib/libexslt.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libexslt.so"

chown 0.0 "/system/lib/libxslt.so"
chmod 0644 "/system/lib/libxslt.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libxslt.so"

chown 0.0 "/system/lib/xsltConf.sh"
chmod 0644 "/system/lib/xsltConf.sh"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/xsltConf.sh"

# 1.1.34 [2021.11.25]

source_2="Termux Make"

chown 0.0 "/system/lib64/libexslt.so"
chmod 0644 "/system/lib64/libexslt.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libexslt.so"

chown 0.0 "/system/lib64/libxslt.so"
chmod 0644 "/system/lib64/libxslt.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libxslt.so"

chown 0.2000 "/system/xbin/xslt-config"
chmod 0755 "/system/xbin/xslt-config"

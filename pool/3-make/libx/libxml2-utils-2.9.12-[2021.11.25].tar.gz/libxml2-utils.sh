#!/system/bin/sh

# SHELL SCRIPT (SH)

name="libxml2-utils"
version="2.9.12 [2021.11.25]"

# 2.9.12 [2021.11.25]

source="Termux Make"

chown 0.2000 "/system/xbin/xmlcatalog"
chmod 0755 "/system/xbin/xmlcatalog"

chown 0.2000 "/system/xbin/xmllint"
chmod 0755 "/system/xbin/xmllint"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="jp2a"
version="1.1.1 [2021.11.21]"

# 1.1.1 [2021.11.21]

source="Termux Make"

chown 0.2000 "/system/xbin/jp2a"
chmod 0755 "/system/xbin/jp2a"

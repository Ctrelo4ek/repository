#!/system/bin/sh

# SHELL SCRIPT (SH)

name="gawk [gnu-awk]"
version="5.1.0 [API 3.0] [2020.10.17]"

# 5.1.0 [API 3.0] [2020.10.17]

source="https://github.com/henriknelson/gawk-magisk-module"
source_2="https://github.com/Zackptg5/GNU-Utils-Android"

chown -hR 0.0 "/system/etc/awk"
chmod -R 0644 "/system/etc/awk"

find "/system/etc/awk" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/awk" "/system/usr/share/awk"

chown -hR 0.2000 "/system/etc/profile.d"
chmod -R 0755 "/system/etc/profile.d"

find "/system/system/etc/profile.d" -type d \( -exec chown -h 0.2000 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.2000 {} + -exec chmod 0755 {} + \)

ln -s "../../etc/profile.d" "/system/usr/share/profile.d"

chown -hR 0.0 "/system/lib/gawk"
chmod -R 0644 "/system/lib/gawk"

find "/system/lib/gawk" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../lib/gawk" "/system/lib64/gawk"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/gawk"

chown 0.2000 "/system/libexec"
chmod 0755 "/system/libexec"

chown -hR 0.2000 "/system/libexec/awk"
chmod -R 0755 "/system/libexec/awk"

find "/system/libexec/awk" -type d \( -exec chown -h 0.2000 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.2000 {} + -exec chmod 0755 {} + \)

chown 0.2000 "/system/xbin/gawk"
chmod 0755 "/system/xbin/gawk"

ln -s "gawk" "/system/xbin/gawk-5.1.0"

if [ ! -f "/system/xbin/awk" ]; then
	ln -s "gawk" "/system/xbin/awk"
fi

chown 0.2000 "/system/xbin/grcat"
chmod 0755 "/system/xbin/grcat"

ln -s "../../xbin/grcat" "/system/libexec/awk/grcat"

chown 0.2000 "/system/xbin/pwcat"
chmod 0755 "/system/xbin/pwcat"

ln -s "../../xbin/pwcat" "/system/libexec/awk/pwcat"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="nano"
version="5.9 [2021.11.10]"

# 5.9 [2021.11.10]

source="https://github.com/henriknelson/nano-magisk-module"
source_2="Termux Make"

chown -hR 0.0 "/system/etc/nano"
chmod -R 0644 "/system/etc/nano"

find "/system/etc/nano" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "git.nanorc" "/system/etc/nano/filetype/gitcommit.nanorc"
ln -s "html.nanorc" "/system/etc/nano/filetype/html.j2.nanorc"
ln -s "html.nanorc" "/system/etc/nano/filetype/twig.nanorc"
ln -s "povray.nanorc" "/system/etc/nano/filetype/pov.nanorc"
ln -s "vi.nanorc" "/system/etc/nano/filetype/vim.nanorc"
ln -s "zsh.nanorc" "/system/etc/nano/filetype/zshrc.nanorc"

ln -s "../../etc/nano" "/system/usr/share/nano"
ln -s "nano/nanorc" "/system/etc/nanorc"

chown 0.2000 "/system/xbin/nano"
chmod 0755 "/system/xbin/nano"

ln -s "nano" "/system/xbin/rnano"

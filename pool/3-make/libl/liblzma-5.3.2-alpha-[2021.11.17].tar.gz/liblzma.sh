#!/system/bin/sh

# SHELL SCRIPT (SH)

name="liblzma"
version="5.3.2 Alpha [2021.11.17]"

# 11.0

source="Android"

chown -hR 0.0 "/system/etc/pkgconfig"
chmod -R 0644 "/system/etc/pkgconfig"

find "/system/etc/pkgconfig" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/pkgconfig" "/system/usr/share/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib64/pkgconfig"

chown 0.0 "/system/lib/liblzma.la"
chmod 0644 "/system/lib/liblzma.la"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/liblzma.la"

chown 0.0 "/system/lib/liblzma.so"
chmod 0644 "/system/lib/liblzma.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/liblzma.so"

chown 0.0 "/system/lib64/liblzma.so"
chmod 0644 "/system/lib64/liblzma.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/liblzma.so"

# 5.2.5 [Build 1] [2021.02.23]

source_2="Termux"

chown 0.0 "/system/lib/liblzma5.so"
chmod 0644 "/system/lib/liblzma5.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/liblzma5.so"

# 5.3.2 Alpha [2021.11.17]

source_3="Termux Make"

chown 0.0 "/system/lib64/liblzma5.so"
chmod 0644 "/system/lib64/liblzma5.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/liblzma5.so"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="xsltproc-[libxslt]"
version="1.1.34 [2021.11.25]"

# 1.1.34 [2021.11.25]

source="Termux Make"

chown 0.2000 "/system/xbin/xsltproc"
chmod 0755 "/system/xbin/xsltproc"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="xz"
version="5.3.2 Alpha [2021.11.17]"

# 5.3.2 Alpha [2021.11.17]

source="Termux Make"

chown 0.2000 "/system/xbin/lzmadec"
chmod 0755 "/system/xbin/lzmadec"

chown 0.2000 "/system/xbin/lzmainfo"
chmod 0755 "/system/xbin/lzmainfo"

chown 0.2000 "/system/xbin/scanlzma"
chmod 0755 "/system/xbin/scanlzma"

chown 0.2000 "/system/xbin/xz"
chmod 0755 "/system/xbin/xz"

ln -s "xz" "/system/xbin/lzcat"
ln -s "xz" "/system/xbin/lzma"
ln -s "xz" "/system/xbin/unlzma"
ln -s "xz" "/system/xbin/unxz"
ln -s "xz" "/system/xbin/xzcat"

chown 0.2000 "/system/xbin/xzdec"
chmod 0755 "/system/xbin/xzdec"

chown 0.2000 "/system/xbin/xzdiff"
chmod 0755 "/system/xbin/xzdiff"

ln -s "xzdiff" "/system/xbin/lzcmp"
ln -s "xzdiff" "/system/xbin/lzdiff"
ln -s "xzdiff" "/system/xbin/xzcmp"

chown 0.2000 "/system/xbin/xzgrep"
chmod 0755 "/system/xbin/xzgrep"

ln -s "xzgrep" "/system/xbin/lzegrep"
ln -s "xzgrep" "/system/xbin/lzfgrep"
ln -s "xzgrep" "/system/xbin/lzgrep"
ln -s "xzgrep" "/system/xbin/xzegrep"
ln -s "xzgrep" "/system/xbin/xzfgrep"

chown 0.2000 "/system/xbin/xzless"
chmod 0755 "/system/xbin/xzless"

ln -s "xzless" "/system/xbin/lzless"

chown 0.2000 "/system/xbin/xzmore"
chmod 0755 "/system/xbin/xzmore"

ln -s "xzmore" "/system/xbin/lzmore"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="bind [dnsutils]"
version="9.17.6 [2020.11.17]"

# 9.16.9

source="Termux"

chown 0.0 "/system/lib/libbind9.so"
chmod 0644 "/system/lib/libbind9.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libbind9.so"

chown 0.0 "/system/lib/libdns.so"
chmod 0644 "/system/lib/libdns.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libdns.so"

chown 0.0 "/system/lib/libirs.so"
chmod 0644 "/system/lib/libirs.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libirs.so"

chown 0.0 "/system/lib/libisc.so"
chmod 0644 "/system/lib/libisc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libisc.so"

chown 0.0 "/system/lib/libisccc.so"
chmod 0644 "/system/lib/libisccc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libisccc.so"

chown 0.0 "/system/lib/libisccfg.so"
chmod 0644 "/system/lib/libisccfg.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libisccfg.so"

chown 0.0 "/system/lib/libns.so"
chmod 0644 "/system/lib/libns.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/libns.so"

# 9.17.6 [2020.11.17]

source_2="Termux Make"

chown 0.0 "/system/etc/bind.keys"
chmod 0644 "/system/etc/bind.keys"

chown 0.0 "/system/etc/named.conf"
chmod 0644 "/system/etc/named.conf"

chown -hR 0.0 "/system/lib/rndc.conf"
chmod -R 0644 "/system/lib/rndc.conf"

find "/system/lib/named" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../lib/named" "/system/lib64/named"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/named"

chown 0.0 "/system/lib64/libbind9.so"
chmod 0644 "/system/lib64/libbind9.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libbind9.so"

chown 0.0 "/system/lib64/libdns.so"
chmod 0644 "/system/lib64/libdns.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libdns.so"

chown 0.0 "/system/lib64/libirs.so"
chmod 0644 "/system/lib64/libirs.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libirs.so"

chown 0.0 "/system/lib64/libisc.so"
chmod 0644 "/system/lib64/libisc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libisc.so"

chown 0.0 "/system/lib64/libisccc.so"
chmod 0644 "/system/lib64/libisccc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libisccc.so"

chown 0.0 "/system/lib64/libisccfg.so"
chmod 0644 "/system/lib64/libisccfg.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libisccfg.so"

chown 0.0 "/system/lib64/libns.so"
chmod 0644 "/system/lib64/libns.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libns.so"

chown 0.2000 "/system/xbin/cfg_gen"
chmod 0755 "/system/xbin/cfg_gen"

chown 0.2000 "/system/xbin/cfg_test"
chmod 0755 "/system/xbin/cfg_test"

chown 0.2000 "/system/xbin/ddns-confgen"
chmod 0755 "/system/xbin/ddns-confgen"

ln -s "ddns-confgen" "/system/xbin/tsig-keygen"

chown 0.2000 "/system/xbin/delv"
chmod 0755 "/system/xbin/delv"

chown 0.2000 "/system/xbin/dig"
chmod 0755 "/system/xbin/dig"

chown 0.2000 "/system/xbin/dnssec-cds"
chmod 0755 "/system/xbin/dnssec-cds"

chown 0.2000 "/system/xbin/dnssec-dsfromkey"
chmod 0755 "/system/xbin/dnssec-dsfromkey"

chown 0.2000 "/system/xbin/dnssec-importkey"
chmod 0755 "/system/xbin/dnssec-importkey"

chown 0.2000 "/system/xbin/dnssec-keyfromlabel"
chmod 0755 "/system/xbin/dnssec-keyfromlabel"

chown 0.2000 "/system/xbin/dnssec-keygen"
chmod 0755 "/system/xbin/dnssec-keygen"

chown 0.2000 "/system/xbin/dnssec-revoke"
chmod 0755 "/system/xbin/dnssec-revoke"

chown 0.2000 "/system/xbin/dnssec-settime"
chmod 0755 "/system/xbin/dnssec-settime"

chown 0.2000 "/system/xbin/dnssec-signzone"
chmod 0755 "/system/xbin/dnssec-signzone"

chown 0.2000 "/system/xbin/dnssec-verify"
chmod 0755 "/system/xbin/dnssec-verify"

chown 0.2000 "/system/xbin/host"
chmod 0755 "/system/xbin/host"

chown 0.2000 "/system/xbin/mdig"
chmod 0755 "/system/xbin/mdig"

chown 0.2000 "/system/xbin/named"
chmod 0755 "/system/xbin/named"

chown 0.2000 "/system/xbin/named-checkconf"
chmod 0755 "/system/xbin/named-checkconf"

chown 0.2000 "/system/xbin/named-checkzone"
chmod 0755 "/system/xbin/named-checkzone"

ln -s "named-checkzone" "/system/xbin/named-compilezone"

chown 0.2000 "/system/xbin/named-journalprint"
chmod 0755 "/system/xbin/named-journalprint"

chown 0.2000 "/system/xbin/named-rrchecker"
chmod 0755 "/system/xbin/named-rrchecker"

chown 0.2000 "/system/xbin/nsec3hash"
chmod 0755 "/system/xbin/nsec3hash"

chown 0.2000 "/system/xbin/nslookup"
chmod 0755 "/system/xbin/nslookup"

chown 0.2000 "/system/xbin/nsprobe"
chmod 0755 "/system/xbin/nsprobe"

chown 0.2000 "/system/xbin/nsupdate"
chmod 0755 "/system/xbin/nsupdate"

chown 0.2000 "/system/xbin/resolve"
chmod 0755 "/system/xbin/resolve"

chown 0.2000 "/system/xbin/rndc"
chmod 0755 "/system/xbin/rndc"

chown 0.2000 "/system/xbin/rndc-confgen"
chmod 0755 "/system/xbin/rndc-confgen"

chown 0.2000 "/system/xbin/sample-async"
chmod 0755 "/system/xbin/sample-async"

chown 0.2000 "/system/xbin/sample-request"
chmod 0755 "/system/xbin/sample-request"

chown 0.2000 "/system/xbin/sample-update"
chmod 0755 "/system/xbin/sample-update"

chown 0.2000 "/system/xbin/wire_test"
chmod 0755 "/system/xbin/wire_test"

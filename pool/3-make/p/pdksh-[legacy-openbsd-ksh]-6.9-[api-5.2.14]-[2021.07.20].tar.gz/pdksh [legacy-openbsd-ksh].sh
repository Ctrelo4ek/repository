#!/system/bin/sh

# SHELL SCRIPT (SH)

name="pdksh [legacy-openbsd-ksh]"
version="6.9 [API 5.2.14] [2021.07.20]"

# 6.9 [API 5.2.14] [2021.07.20]

source="Termux Make"
source_2="https://github.com/dimkr/loksh"

chown 0.0 "/system/etc/kshrc"
chmod 0644 "/system/etc/kshrc"

chown 0.0 "/system/etc/mkshrc"
chmod 0644 "/system/etc/mkshrc"

chown 0.2000 "/system/etc/shells"
chmod 0755 "/system/etc/shells"

chown 0.2000 "/system/xbin/pdksh"
chmod 0755 "/system/xbin/pdksh"

ln -s "pdksh" "/system/xbin/ksh"
ln -s "pdksh" "/system/xbin/loksh"
ln -s "pdksh" "/system/xbin/oksh"
ln -s "pdksh" "/system/xbin/rksh"
ln -s "pdksh" "/system/xbin/rloksh"
ln -s "pdksh" "/system/xbin/roksh"
ln -s "pdksh" "/system/xbin/rpdksh"

chcon -hR u:object_r:shell_exec:s0 "/system/xbin/pdksh"

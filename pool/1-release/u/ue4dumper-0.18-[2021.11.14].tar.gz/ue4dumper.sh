#!/system/bin/sh

# SHELL SCRIPT (SH)

name="ue4dumper"
version="0.18 [2021.11.14]"

# 0.18 [2021.11.14]

source="https://github.com/kp7742/UE4Dumper"

chown 0.2000 "/system/xbin/ue4dumper64"
chmod 0755 "/system/xbin/ue4dumper64"

ln -s "ue4dumper64" "/system/xbin/ue4dumper"

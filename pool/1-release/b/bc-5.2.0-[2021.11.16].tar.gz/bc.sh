#!/system/bin/sh

# SHELL SCRIPT (SH)

name="bc"
version="5.2.0 [2021.11.16]"

# 5.2.0 [2021.11.16]

source="Termux Make"

chown 0.2000 "/system/bin/bc"
chmod 0755 "/system/bin/bc"

# ln -s "bc" "/system/bin/dc"

chown 0.2000 "/system/bin/dc"
chmod 0755 "/system/bin/dc"

chown 0.2000 "/system/bin/strgen"
chmod 0755 "/system/bin/strgen"

chown -hR 0.0 "/system/etc/pkgconfig"
chmod -R 0644 "/system/etc/pkgconfig"

find "/system/etc/pkgconfig" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/pkgconfig" "/system/usr/share/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib64/pkgconfig"

chown 0.0 "/system/lib64/libbcl.so"
chmod 0644 "/system/lib64/libbcl.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libbcl.so"

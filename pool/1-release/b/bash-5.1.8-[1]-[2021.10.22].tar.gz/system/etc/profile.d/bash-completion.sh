# /system/etc/profile.d/bash-completion

# Библиотеки подстановки комманд

if [ "x${BASH_VERSION-}" != x -a "x${PS1-}" != x -a "x${BASH_COMPLETION_VERSINFO-}" = x ]; then
	if [ "${BASH_VERSINFO[0]}" -gt 4 ] ||
		[ "${BASH_VERSINFO[0]}" -eq 4 -a "${BASH_VERSINFO[1]}" -ge 2 ]; then
		if [ -r "/system/etc/bash-completion/bash_completion" ]; then
			shopt -q progcomp
			source "/system/etc/bash-completion/bash_completion"
		fi
	fi
fi

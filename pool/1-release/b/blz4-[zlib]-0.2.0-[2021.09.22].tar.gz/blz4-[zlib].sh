#!/system/bin/sh

# SHELL SCRIPT (SH)

name="blz4 [zlib]"
version="0.2.0 [2021.09.22]"

# 0.2.0 [2021.09.22]

source="Termux Make"

chown 0.0 "/system/lib64/libblz4.so"
chmod 0644 "/system/lib64/libblz4.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libblz4.so"

chown 0.2000 "/system/xbin/blz4"
chmod 0755 "/system/xbin/blz4"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="minicap"
version="2.6.0 Alpha [API 30]"

# 2.6.0 Alpha [API 30]

source="https://github.com/DeviceFarmer/minicap"

chown 0.0 "/system/lib/minicap.so"
chmod 0644 "/system/lib/minicap.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib/minicap.so"

chown 0.0 "/system/lib64/minicap.so"
chmod 0644 "/system/lib64/minicap.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/minicap.so"

chown 0.2000 "/system/xbin/minicap"
chmod 0755 "/system/xbin/minicap"

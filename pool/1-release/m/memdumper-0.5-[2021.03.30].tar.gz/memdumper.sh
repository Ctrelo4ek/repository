#!/system/bin/sh

# SHELL SCRIPT (SH)

name="memdumper"
version="0.5 [2021.03.30]"

# 0.5 [2021.03.30]

source="https://github.com/kp7742/MemDumper"

chown 0.2000 "/system/xbin/memdumper64"
chmod 0755 "/system/xbin/memdumper64"

ln -s "memdumper64" "/system/xbin/memdumper"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="gnu-bc"
version="1.07.1"

# 1.07.1

source="https://github.com/Zackptg5/GNU-Utils-Android"

chown -hR 0.0 "/system/etc/pkgconfig"
chmod -R 0644 "/system/etc/pkgconfig"

find "/system/etc/pkgconfig" -type d \( -exec chown -h 0.0 {} + -exec chmod 0755 {} + \) -o -type f \( -exec chown -h 0.0 {} + -exec chmod 0644 {} + \)

ln -s "../../etc/pkgconfig" "/system/usr/share/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib/pkgconfig"
ln -s "../etc/pkgconfig" "/system/lib64/pkgconfig"

chown 0.0 "/system/lib64/libbc.so"
chmod 0644 "/system/lib64/libbc.so"

chcon -hR u:object_r:system_lib_file:s0 "/system/lib64/libbc.so"

chown 0.2000 "/system/xbin/bc"
chmod 0755 "/system/xbin/bc"

# ln -s "bc" "/system/xbin/dc"
ln -s "bc" "/system/xbin/gnu-bc"
# ln -s "bc" "/system/xbin/gnu-dc"

# 1.4.1 [bc 1.07.1]

chown 0.2000 "/system/xbin/dc"
chmod 0755 "/system/xbin/dc"

ln -s "dc" "/system/xbin/gnu-dc"

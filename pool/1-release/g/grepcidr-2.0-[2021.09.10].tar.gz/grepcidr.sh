#!/system/bin/sh

# SHELL SCRIPT (SH)

name="grepcidr"
version="2.0 [2021.09.10]"

# 2.0 [2021.09.10]

source="Termux Make"

chown 0.2000 "/system/xbin/grepcidr"
chmod 0755 "/system/xbin/grepcidr"

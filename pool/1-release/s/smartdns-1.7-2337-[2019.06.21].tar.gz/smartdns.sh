#!/system/bin/sh

# SHELL SCRIPT (SH)

name="smartdns"
version="1.7-2337 [2019.06.21]"

# 1.7-2337 [2019.06.21]

source="Termux Make"

chown 0.0 "/system/etc/smartdns.conf"
chmod 0644 "/system/etc/smartdns.conf"

chown 0.2000 "/system/xbin/smartdns"
chmod 0755 "/system/xbin/smartdns"

chown 0.2000 "/system/xbin/smartdns.sh"
chmod 0755 "/system/xbin/smartdns.sh"

#!/system/bin/sh

script_home="${0}"
script_folder="$( cd "$( dirname "${0}" )"; pwd )"
script_name="${0##*/}"

configuration="/system/etc/smartdns.conf"

exec ${script_folder}/smartdns -c ${configuration} "${@}"

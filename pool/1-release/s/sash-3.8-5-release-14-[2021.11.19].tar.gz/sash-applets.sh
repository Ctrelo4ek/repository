#!/system/bin/sh

# SHELL SCRIPT (SH)

name="sash"
version="3.8-5 Release 14 [2021.11.19]"

# 3.8-5 Release 14 [2021.11.19] / 35 Applets [ARM 64]

source="Termux Make"
source_2="https://http.kali.org/pool/main/s/sash"
source_3="https://mirror.yandex.ru/debian/pool/main/s/sash"

chown 0.2000 "/system/etc/shells"
chmod 0755 "/system/etc/shells"

chown 0.2000 "/system/xbin/applets"
chmod 0755 "/system/xbin/applets"

chown 0.2000 "/system/xbin/sash"
chmod 0755 "/system/xbin/sash"

ln -s "../sash" "/system/xbin/applets/ar"
ln -s "../sash" "/system/xbin/applets/chattr"
ln -s "../sash" "/system/xbin/applets/chgrp"
ln -s "../sash" "/system/xbin/applets/chmod"
ln -s "../sash" "/system/xbin/applets/chown"
ln -s "../sash" "/system/xbin/applets/cmp"
ln -s "../sash" "/system/xbin/applets/cp"
ln -s "../sash" "/system/xbin/applets/dd"
ln -s "../sash" "/system/xbin/applets/echo"
ln -s "../sash" "/system/xbin/applets/ed"
ln -s "../sash" "/system/xbin/applets/file"
ln -s "../sash" "/system/xbin/applets/find"
ln -s "../sash" "/system/xbin/applets/grep"
ln -s "../sash" "/system/xbin/applets/gunzip"
ln -s "../sash" "/system/xbin/applets/gzip"
ln -s "../sash" "/system/xbin/applets/kill"
ln -s "../sash" "/system/xbin/applets/losetup"
ln -s "../sash" "/system/xbin/applets/ln"
ln -s "../sash" "/system/xbin/applets/ls"
ln -s "../sash" "/system/xbin/applets/lsattr"
ln -s "../sash" "/system/xbin/applets/mkdir"
ln -s "../sash" "/system/xbin/applets/mknod"
ln -s "../sash" "/system/xbin/applets/more"
ln -s "../sash" "/system/xbin/applets/mount"
ln -s "../sash" "/system/xbin/applets/mv"
ln -s "../sash" "/system/xbin/applets/printenv"
ln -s "../sash" "/system/xbin/applets/pwd"
ln -s "../sash" "/system/xbin/applets/rm"
ln -s "../sash" "/system/xbin/applets/rmdir"
ln -s "../sash" "/system/xbin/applets/sum"
ln -s "../sash" "/system/xbin/applets/sync"
ln -s "../sash" "/system/xbin/applets/tar"
ln -s "../sash" "/system/xbin/applets/touch"
ln -s "../sash" "/system/xbin/applets/umount"
ln -s "../sash" "/system/xbin/applets/where"

chcon -hR u:object_r:shell_exec:s0 "/system/xbin/sash"

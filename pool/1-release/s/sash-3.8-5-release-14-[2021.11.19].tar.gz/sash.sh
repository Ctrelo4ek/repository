#!/system/bin/sh

# SHELL SCRIPT (SH)

name="sash"
version="3.8-5 Release 14 [2021.11.19]"

# 3.8-5 Release 14 [2021.11.19] / 35 Applets [ARM 64]

source="Termux Make"
source_2="https://http.kali.org/pool/main/s/sash"
source_3="https://mirror.yandex.ru/debian/pool/main/s/sash"

chown 0.2000 "/system/etc/shells"
chmod 0755 "/system/etc/shells"

chown 0.2000 "/system/xbin/applets"
chmod 0755 "/system/xbin/applets"

chown 0.2000 "/system/xbin/sash"
chmod 0755 "/system/xbin/sash"

ln -s "sash" "/system/xbin/ar"
ln -s "sash" "/system/xbin/chattr"
ln -s "sash" "/system/xbin/chgrp"
ln -s "sash" "/system/xbin/chmod"
ln -s "sash" "/system/xbin/chown"
ln -s "sash" "/system/xbin/cmp"
ln -s "sash" "/system/xbin/cp"
ln -s "sash" "/system/xbin/dd"
ln -s "sash" "/system/xbin/echo"
ln -s "sash" "/system/xbin/ed"
ln -s "sash" "/system/xbin/file"
ln -s "sash" "/system/xbin/find"
ln -s "sash" "/system/xbin/grep"
ln -s "sash" "/system/xbin/gunzip"
ln -s "sash" "/system/xbin/gzip"
ln -s "sash" "/system/xbin/kill"
ln -s "sash" "/system/xbin/losetup"
ln -s "sash" "/system/xbin/ln"
ln -s "sash" "/system/xbin/ls"
ln -s "sash" "/system/xbin/lsattr"
ln -s "sash" "/system/xbin/mkdir"
ln -s "sash" "/system/xbin/mknod"
ln -s "sash" "/system/xbin/more"
ln -s "sash" "/system/xbin/mount"
ln -s "sash" "/system/xbin/mv"
ln -s "sash" "/system/xbin/printenv"
ln -s "sash" "/system/xbin/pwd"
ln -s "sash" "/system/xbin/rm"
ln -s "sash" "/system/xbin/rmdir"
ln -s "sash" "/system/xbin/sum"
ln -s "sash" "/system/xbin/sync"
ln -s "sash" "/system/xbin/tar"
ln -s "sash" "/system/xbin/touch"
ln -s "sash" "/system/xbin/umount"
ln -s "sash" "/system/xbin/where"

chcon -hR u:object_r:shell_exec:s0 "/system/xbin/sash"

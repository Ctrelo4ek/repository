#!/system/bin/sh

# SHELL SCRIPT (SH)

name="zrun [zlib]"
version="1.1 [2021.09.15]"

# 1.1 [2021.09.15]

source="Termux Make"

chown 0.2000 "/system/xbin/zrun"
chmod 0755 "/system/xbin/zrun"

#!/system/bin/sh

# SHELL SCRIPT (SH)

name="e2tools"
version="0.1.0 [2021.12.05]"

# 0.1.0 [2021.12.05]

source="Termux Make"

chown 0.2000 "/system/xbin/e2tools"
chmod 0755 "/system/xbin/e2tools"

ln -s "e2tools" "/system/xbin/e2cp"
ln -s "e2tools" "/system/xbin/e2ln"
ln -s "e2tools" "/system/xbin/e2ls"
ln -s "e2tools" "/system/xbin/e2mkdir"
ln -s "e2tools" "/system/xbin/e2mv"
ln -s "e2tools" "/system/xbin/e2rm"
ln -s "e2tools" "/system/xbin/e2tail"
